package Execute;

import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.FlatLaf;
import ventanas.VentanaLoggin;

public class Execute {
    public static void main(String[] args) {
        try {
            // Registra el archivo .properties con el tema personalizado
            FlatLaf.registerCustomDefaultsSource("temas");  
            FlatLightLaf.setup();

        } catch (Exception e) {
            System.err.println("No se pudo aplicar el tema personalizado");
            e.printStackTrace();
        }

        // Muestra la ventana de login
        new VentanaLoggin().setVisible(true);
    }
}
