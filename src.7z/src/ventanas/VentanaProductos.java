package ventanas;

import conexiones.Conexiones;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jfran
 */
public class VentanaProductos extends javax.swing.JFrame {

    public VentanaProductos() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);
        Mostrar("productos");
    }

    //=================== METODO MOSTRAR DATOS EN TABLA ========================      
    public void Mostrar(String tabla) {
        Connection con = Conexiones.conectar();
        String sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.existencia, c.nombre_categoria, p.fecha_ingreso "
                + "FROM " + tabla + " p "
                + "JOIN categorias c ON p.id_categoria = c.id_categoria "
                + "ORDER BY p.id_producto ASC";

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{"ID", "NOMBRE", "DESCRIPCION", "PRECIO", "EXISTENCIA", "CATEGORIA", "FECHA_INGRESO"}
        ) {
            // Metodo especifico Preelaborado
            public boolean isCellEditable(int row, int column) { // VERIFICA QUE NOO SE EDITE LA TABLA POR EL USUARIO
                return false;
            }

        };
        tabla_productos.getTableHeader().setFont(new Font("Verdana", Font.BOLD, 14)); // DISENIO DE NOMBRE DE CAMPOS
        tabla_productos.setModel(modelo);

        for (int f = 0; f < tabla_productos.getColumnCount(); f++) {
            tabla_productos.getColumnModel().getColumn(f).setResizable(true);
        }

        String[] datos = new String[7];

        try {
            Statement consulta = con.createStatement();
            ResultSet resultado = consulta.executeQuery(sql);

            while (resultado.next()) {
                datos[0] = resultado.getString("ID_PRODUCTO");
                datos[1] = resultado.getString("NOMBRE");
                datos[2] = resultado.getString("DESCRIPCION");
                datos[3] = resultado.getString("PRECIO");
                datos[4] = resultado.getString("EXISTENCIA");
                datos[5] = resultado.getString("NOMBRE_CATEGORIA");
                datos[6] = resultado.getString("FECHA_INGRESO");
                modelo.addRow(datos); // agrega los datoos adquiridos al modelo de la tabla.
                configurarTabla();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        centrarTexto(tabla_productos);
    }

    //=================== METODOS PARA BUSCAR PRODUCTOS ========================
    public void Buscar_Id_producto() {
        String idProducto = t_idProducto.getText();
        if (idProducto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "INGRESE ID DE PRODUCTO", "AVISO",
                    JOptionPane.WARNING_MESSAGE);
            return;  // vuelve a pedir el ingreso del Id en la casilla
        }

        String sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.existencia, c.nombre_categoria, p.fecha_ingreso "
                + "FROM productos p "
                + "JOIN categorias c ON p.id_categoria = c.id_categoria "
                + "WHERE p.id_producto = ?";

        DefaultTableModel modelo = (DefaultTableModel) tabla_productos.getModel();
        modelo.setRowCount(0); // limpiar tabla antes de mostrar resultados.

        try (Connection con = Conexiones.conectar(); PreparedStatement consulta = con.prepareStatement(sql)) {

            consulta.setString(1, idProducto);
            ResultSet resultado = consulta.executeQuery(); // LE PASAMMOS A LA BASE PARA QUE CONSUTE EL VALOR

            if (resultado.next()) {
                String[] datos = {
                    resultado.getString("id_producto"),
                    resultado.getString("Nombre"),
                    resultado.getString("descripcion"),
                    resultado.getString("precio"),
                    resultado.getString("existencia"),
                    resultado.getString("nombre_categoria"),
                    resultado.getString("fecha_ingreso"),};
                modelo.addRow(datos); // Le pasamos los datos del array a la taba.
            } else {
                JOptionPane.showMessageDialog(this, "PRODUCTO NO EXISTE", "RESULTADO DE BUSQUEDA",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "ERROR: ",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void Buscar_categoria() {
        String categoria = t_categoria.getText();
        if (categoria.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR CATEGORIA DE PRODUTO", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return; // vuelve a la espera del nombre cliente
        }

        String sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.existencia, c.nombre_categoria, p.fecha_ingreso "
                + "FROM productos p "
                + "JOIN categorias c ON p.id_categoria = c.id_categoria "
                + "WHERE c.nombre_categoria LIKE ?";

        DefaultTableModel modelo = (DefaultTableModel) tabla_productos.getModel();
        modelo.setRowCount(0);

        try {
            Connection con = Conexiones.conectar();
            PreparedStatement consulta = con.prepareStatement(sql);

            consulta.setString(1, "%" + categoria + "%");
            ResultSet resultado = consulta.executeQuery();

            boolean encontrado = false;

            while (resultado.next()) {
                String[] datos = {
                    resultado.getString("id_producto"),
                    resultado.getString("Nombre"),
                    resultado.getString("descripcion"),
                    resultado.getString("precio"),
                    resultado.getString("existencia"),
                    resultado.getString("nombre_categoria"),
                    resultado.getString("fecha_ingreso"),};
                modelo.addRow(datos); // pasa los valores a la tabla.
                encontrado = true;
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "PRODUCTO NO ENCONTRADO", "RESULTADO",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BUSQUEDA", "ERROR",
                    JOptionPane.ERROR_MESSAGE);

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b_administrar = new javax.swing.JButton();
        t_categoria = new javax.swing.JTextField();
        t_idProducto = new javax.swing.JTextField();
        l_Categoria = new javax.swing.JLabel();
        l_idProducto = new javax.swing.JLabel();
        b_buscar = new javax.swing.JButton();
        t_clientes = new javax.swing.JScrollPane();
        tabla_productos = new javax.swing.JTable();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_modulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        b_refresh1 = new javax.swing.JButton();
        logo_principal = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MODULO DE PRODUCTOS");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        b_administrar.setBackground(new java.awt.Color(51, 153, 0));
        b_administrar.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        b_administrar.setForeground(new java.awt.Color(255, 255, 255));
        b_administrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/admin.png"))); // NOI18N
        b_administrar.setText("Administrar");
        b_administrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_administrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_administrarActionPerformed(evt);
            }
        });
        getContentPane().add(b_administrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 190, 40));

        t_categoria.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 150, 130, 40));

        t_idProducto.setBackground(new java.awt.Color(255, 255, 255));
        t_idProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_idProductoActionPerformed(evt);
            }
        });
        getContentPane().add(t_idProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 100, 50, 30));

        l_Categoria.setBackground(new java.awt.Color(51, 153, 0));
        l_Categoria.setForeground(new java.awt.Color(0, 0, 0));
        l_Categoria.setText("Categoria");
        getContentPane().add(l_Categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 160, 70, -1));

        l_idProducto.setBackground(new java.awt.Color(51, 153, 0));
        l_idProducto.setForeground(new java.awt.Color(0, 0, 0));
        l_idProducto.setText("idProducto");
        getContentPane().add(l_idProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 110, 70, -1));

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(b_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 100, 120, 90));

        tabla_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "NOMBRE", "DESCRIPCION", "PRECIO", "EXISTENCIA", "CATEGORIA", "FECHA INGRESO"
            }
        ));
        t_clientes.setViewportView(tabla_productos);

        getContentPane().add(t_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 1330, 270));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(1280, 510, 110, 40));

        l_modulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_modulo.setForeground(new java.awt.Color(0, 102, 102));
        l_modulo.setText("Modulo de Productos");
        getContentPane().add(l_modulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, -1, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Buscar id o categoria de producto");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 40, -1, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 520, 130, 50));

        b_refresh1.setBackground(new java.awt.Color(204, 204, 204));
        b_refresh1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        b_refresh1.setForeground(new java.awt.Color(255, 255, 255));
        b_refresh1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando (5).png"))); // NOI18N
        b_refresh1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_refresh1ActionPerformed(evt);
            }
        });
        getContentPane().add(b_refresh1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 240, 40, 40));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_productos.jpg"))); // NOI18N
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //=================== METODOS ACTION LISTENER  =============================
    private void b_administrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_administrarActionPerformed
        new VentanaAdminProductos().setVisible(true);

    }//GEN-LAST:event_b_administrarActionPerformed

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        dispose();
        new ventanaPrincipal(true).setVisible(true);
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null,
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        if (!t_idProducto.getText().isEmpty()) {
            Buscar_Id_producto();
            limpiar();
        } else if (!t_categoria.getText().isEmpty()) {
            Buscar_categoria();
            limpiar();
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR ID O CATEGORIA DE PRODUCTO", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_b_buscarActionPerformed

    private void t_idProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_idProductoActionPerformed
        t_idProducto.setBackground(Color.RED);

        // Hacer que el campo t_idProducto parpadee para indicar la ejecución de la acción
        Timer timer = new Timer(500, null);
        final int[] count = {0};
        timer.addActionListener(e -> {
            if (count[0] % 2 == 0) {
                t_idProducto.setBackground(Color.YELLOW);
            } else {
                t_idProducto.setBackground(Color.WHITE);
            }
            count[0]++;
            if (count[0] >= 4) {
                timer.stop();
                t_idProducto.setBackground(Color.WHITE);
            }
        });
        timer.start();
    }//GEN-LAST:event_t_idProductoActionPerformed

    private void b_refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_refresh1ActionPerformed
        Mostrar("productos"); // actualizamos mostrando nuevamente la taba.
    }//GEN-LAST:event_b_refresh1ActionPerformed

    //=================== METODOS AUXILIARES  ==================================
    private void configurarTabla() {
        tabla_productos.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla_productos.setEnabled(true);

        tabla_productos.setRowSelectionAllowed(true);
        tabla_productos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tabla_productos.setSelectionBackground(new Color(0, 120, 215));
        tabla_productos.setSelectionForeground(Color.WHITE);
    }

    public void centrarTexto(JTable tabla) {
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centrado);
        }
    }

    private void limpiar() {
        t_idProducto.setText("");
        t_categoria.setText("");
    }

    //=================== METODO MAIN  =========================================
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_administrar;
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_refresh1;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_volver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel l_Categoria;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idProducto;
    private javax.swing.JLabel l_modulo;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JTextField t_categoria;
    private javax.swing.JScrollPane t_clientes;
    private javax.swing.JTextField t_idProducto;
    private javax.swing.JTable tabla_productos;
    // End of variables declaration//GEN-END:variables
}
