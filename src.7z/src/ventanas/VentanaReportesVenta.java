package ventanas;

import conexiones.Conexiones;

import java.awt.Toolkit;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.awt.Color;
import java.awt.Font;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JTable;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class VentanaReportesVenta extends javax.swing.JFrame {

    public VentanaReportesVenta() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        java.awt.Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono); // establecemos el icono  
        configurarTabla();
        mostrarReporteCaja();

    }

    //=================== METODOS DE USUARIOS Y CLIENTES  ======================
    private boolean verificarExistenciaCliente(int idCliente) {
        String sql = "SELECT COUNT(*) FROM clientes WHERE id_cliente = ?";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al verificar cliente:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        return false;
    }

    private boolean verificarExistenciaUsuario(int idUsuario) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE id_usuario = ?";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al verificar usuario:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        return false;
    }
    //=================== METODOS DE REPORTRES =================================

    public void insertarReporteVenta(int idUsuario, String nombreUsuario, String departamento,
            int idCliente, String nombreCliente, BigDecimal valorVenta,
            String horaInicio, String horaFin, java.sql.Date fecha) {

        // Primero verificar que el cliente existe
        if (!verificarExistenciaCliente(idCliente)) {
            JOptionPane.showMessageDialog(
                    this,
                    "El cliente con ID " + idCliente + " no existe en la base de datos.\n"
                    + "Por favor, registre el cliente antes de continuar.",
                    "Error de Referencia",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        // Verificar que el usuario existe
        if (!verificarExistenciaUsuario(idUsuario)) {
            JOptionPane.showMessageDialog(
                    this,
                    "El usuario con ID " + idUsuario + " no existe en la base de datos.\n"
                    + "Por favor, verifique la información del usuario.",
                    "Error de Referencia",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String sql = "INSERT INTO reportesventa (id_usuario, nombre_usuario, departamento, "
                + "id_cliente, nombre_cliente, valor_venta, hora_inicio, hora_fin, fecha) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            ps.setString(2, nombreUsuario);
            ps.setString(3, departamento);
            ps.setInt(4, idCliente);
            ps.setString(5, nombreCliente);
            ps.setBigDecimal(6, valorVenta);
            ps.setString(7, horaInicio);
            ps.setString(8, horaFin);
            ps.setDate(9, fecha);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this,
                    "Reporte de venta registrado exitosamente",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al insertar en reportesventa:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void mostrarReporteCaja() {
        String sql = """
            SELECT 
                rv.id_reportev,
                rv.id_usuario,
                rv.nombre_usuario,
                rv.departamento,
                rv.id_cliente,
                c.nombre AS nombre_cliente,
                rv.valor_venta,
                rv.hora_inicio,
                rv.hora_fin,
                rv.fecha
            FROM reportesventa rv
            LEFT JOIN clientes c ON rv.id_cliente = c.id_cliente
            ORDER BY rv.id_reportev DESC
            """;

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{
                    "ID REPORTE", "ID USUARIO", "NOMBRE USUARIO", "DEPARTAMENTO",
                    "ID CLIENTE", "NOMBRE CLIENTE", "VALOR VENTA", "HORA ENTRADA",
                    "HORA SALIDA", "FECHA"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla_reportes.setModel(modelo);

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_reportev"),
                    rs.getInt("id_usuario"),
                    rs.getString("nombre_usuario"),
                    rs.getString("departamento"),
                    rs.getInt("id_cliente"),
                    rs.getString("nombre_cliente"),
                    rs.getBigDecimal("valor_venta"),
                    rs.getString("hora_inicio"),
                    rs.getString("hora_fin"),
                    rs.getString("fecha")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al mostrar el reporte de caja:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void buscarReporte(String idReporte, Date fecha) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance();

        DefaultTableModel modelo = new DefaultTableModel(
                new String[]{
                    "ID Reporte",
                    "ID Usuario",
                    "Nombre Usuario",
                    "Departamento",
                    "ID Cliente",
                    "Nombre Cliente",
                    "Valor Venta",
                    "Hora Inicio",
                    "Hora Fin",
                    "Fecha"
                },
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = """
        SELECT 
            id_reportev,
            id_usuario,
            nombre_usuario,
            departamento,
            id_cliente,
            nombre_cliente,
            valor_venta,
            hora_inicio,
            hora_fin,
            fecha
        FROM reportesventa
        WHERE 1=1
    """;

        List<String> condiciones = new ArrayList<>();
        List<Object> parametros = new ArrayList<>();

        if (!idReporte.isEmpty()) {
            condiciones.add("id_reportev = ?");
            parametros.add(Integer.parseInt(idReporte));
        }

//        if (!idUsuario.isEmpty()) {
//            condiciones.add("id_usuario = ?");
//            parametros.add(Integer.parseInt(idUsuario));
//        }
        if (fecha != null) {
            condiciones.add("fecha = ?");
            parametros.add(new java.sql.Date(fecha.getTime()));
        }

        if (!condiciones.isEmpty()) {
            sql += " AND " + String.join(" AND ", condiciones);
        }

        sql += " ORDER BY fecha DESC, hora_inicio DESC";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            for (int i = 0; i < parametros.size(); i++) {
                ps.setObject(i + 1, parametros.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    modelo.addRow(new Object[]{
                        rs.getInt("id_reportev"),
                        rs.getInt("id_usuario"),
                        rs.getString("nombre_usuario"),
                        rs.getString("departamento"),
                        rs.getInt("id_cliente"),
                        rs.getString("nombre_cliente"),
                        formatoMoneda.format(rs.getBigDecimal("valor_venta")),
                        rs.getTime("hora_inicio").toString(),
                        rs.getTime("hora_fin").toString(),
                        formatoFecha.format(rs.getDate("fecha"))
                    });
                }
            }

            tabla_reportes.setModel(modelo);
            configurarTablaReportes();

            if (modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(
                        null,
                        "No se encontraron registros para los criterios especificados",
                        "Sin resultados",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error al buscar reportes:\n" + e.getMessage(),
                    "Error de búsqueda",
                    JOptionPane.ERROR_MESSAGE
            );
            e.printStackTrace();
        }
    }

    private void configurarTablaReportes() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);

        TableColumnModel columnModel = tabla_reportes.getColumnModel();

        for (int i = 0; i < tabla_reportes.getColumnCount(); i++) {
            TableColumn column = columnModel.getColumn(i);

            switch (i) {
                case 0, 1, 4: // ID Reporte, ID Usuario, ID Cliente
                    column.setPreferredWidth(80);
                    column.setCellRenderer(centerRenderer);
                    break;
                case 2, 5: // Nombres
                    column.setPreferredWidth(150);
                    break;
                case 3: // Departamento
                    column.setPreferredWidth(120);
                    break;
                case 6: // Valor Venta
                    column.setPreferredWidth(100);
                    column.setCellRenderer(rightRenderer);
                    break;
                case 7, 8: // Horas
                    column.setPreferredWidth(100);
                    column.setCellRenderer(centerRenderer);
                    break;
                case 9: // Fecha
                    column.setPreferredWidth(100);
                    column.setCellRenderer(centerRenderer);
                    break;
            }
        }

        JTableHeader header = tabla_reportes.getTableHeader();
        header.setBackground(new Color(66, 139, 202));
        header.setForeground(Color.BLUE);
        header.setFont(header.getFont().deriveFont(Font.BOLD));

        tabla_reportes.setRowHeight(25);
        tabla_reportes.setShowGrid(true);
        tabla_reportes.setGridColor(new Color(230, 230, 230));
        tabla_reportes.setSelectionBackground(new Color(232, 242, 254));
        tabla_reportes.setSelectionForeground(Color.BLACK);
    }

    //==================  METODOS ACTION LISTENER ==============================
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        t_idReporte = new javax.swing.JTextField();
        l_NumBoleta = new javax.swing.JLabel();
        l_fecha = new javax.swing.JLabel();
        b_buscar = new javax.swing.JButton();
        t_clientes = new javax.swing.JScrollPane();
        tabla_reportes = new javax.swing.JTable();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_modulo = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        b_refresh = new javax.swing.JButton();
        jDate_reporte = new com.toedter.calendar.JDateChooser();
        logo_principal = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MODULO DE VENTAS");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        t_idReporte.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_idReporte, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 110, 40, 30));

        l_NumBoleta.setBackground(new java.awt.Color(51, 153, 0));
        l_NumBoleta.setForeground(new java.awt.Color(0, 0, 0));
        l_NumBoleta.setText("iD reporte");
        getContentPane().add(l_NumBoleta, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 70, -1));

        l_fecha.setBackground(new java.awt.Color(51, 153, 0));
        l_fecha.setForeground(new java.awt.Color(0, 0, 0));
        l_fecha.setText("Buscar fecha");
        getContentPane().add(l_fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 146, 90, 30));

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(b_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 110, 120, 70));

        tabla_reportes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        t_clientes.setViewportView(tabla_reportes);

        getContentPane().add(t_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 950, 270));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 520, 110, 40));

        l_modulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_modulo.setForeground(new java.awt.Color(0, 102, 102));
        l_modulo.setText("Reportes Usuarios ");
        getContentPane().add(l_modulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, -1, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 530, 130, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Filtrar ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 70, 90, -1));

        b_refresh.setBackground(new java.awt.Color(204, 204, 204));
        b_refresh.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        b_refresh.setForeground(new java.awt.Color(255, 255, 255));
        b_refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando (5).png"))); // NOI18N
        b_refresh.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_refreshActionPerformed(evt);
            }
        });
        getContentPane().add(b_refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 180, 40, 40));
        getContentPane().add(jDate_reporte, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 150, -1, -1));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_ventas.jpg"))); // NOI18N
        l_fondo.setToolTipText("");
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        dispose();
        new ventanaPrincipal(true).setVisible(true);
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null,
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        String idReporte = t_idReporte.getText().trim();
        Date fecha = jDate_reporte.getDate();

        if (!idReporte.isEmpty() || fecha != null) {
            buscarReporte(idReporte, fecha);
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NÚMERO DE BOLETA\n"
                    + "O FECHA PARA BUSCAR", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    public void centrarTexto(JTable tabla) {
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centrado);
        }
    }//GEN-LAST:event_b_buscarActionPerformed
    //=================== METODOS AUXILIARES ===================================
    private void limpiar() {
        t_idReporte.setText("");
        jDate_reporte.setDate(null);
    }

    private void configurarTabla() {
        tabla_reportes.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla_reportes.setEnabled(false); // si no quieres que se edite
    }
    private void b_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_refreshActionPerformed
        mostrarReporteCaja();
        limpiar();

    }//GEN-LAST:event_b_refreshActionPerformed
    //=================== METODO CONECCION =====================================
    
    Conexiones Conexiones = new Conexiones();
    java.sql.Connection con = Conexiones.conectar();

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaReportesVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaReportesVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaReportesVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaReportesVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaReportesVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_refresh;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_volver;
    private com.toedter.calendar.JDateChooser jDate_reporte;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel l_NumBoleta;
    private javax.swing.JLabel l_fecha;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_modulo;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JScrollPane t_clientes;
    private javax.swing.JTextField t_idReporte;
    private javax.swing.JTable tabla_reportes;
    // End of variables declaration//GEN-END:variables
}
