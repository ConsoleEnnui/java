package ventanas;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

public class ventanaPrincipal extends javax.swing.JFrame {

    public ventanaPrincipal( boolean esAdmin) {
        initComponents();
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono); 
        setLocationRelativeTo(null); 
        
        if (esAdmin) {
            setSize(1022, 478);
        } else {
            setSize(800, 600);
        }
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_nombremodulo = new javax.swing.JLabel();
        b_clientes = new javax.swing.JButton();
        b_productos = new javax.swing.JButton();
        b_ventas = new javax.swing.JButton();
        b_almacen = new javax.swing.JButton();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        b_mail = new javax.swing.JButton();
        l_pieVentana = new javax.swing.JLabel();
        logo_principal = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();
        menubar = new javax.swing.JMenuBar();
        m_opciones = new javax.swing.JMenu();
        opcion_abrir = new javax.swing.JMenuItem();
        opcion_guardar = new javax.swing.JMenuItem();
        opcion_salir = new javax.swing.JMenuItem();
        m_ayuda = new javax.swing.JMenu();
        acercade = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ventana Principal");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_nombremodulo.setBackground(new java.awt.Color(255, 255, 255));
        l_nombremodulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_nombremodulo.setForeground(new java.awt.Color(0, 102, 102));
        l_nombremodulo.setText("Modulo de Administracion ");
        getContentPane().add(l_nombremodulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        b_clientes.setBackground(new java.awt.Color(51, 153, 0));
        b_clientes.setFont(new java.awt.Font("Dialog", 0, 22)); // NOI18N
        b_clientes.setForeground(new java.awt.Color(255, 255, 255));
        b_clientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/clientes.png"))); // NOI18N
        b_clientes.setText("Clientes");
        b_clientes.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_clientesActionPerformed(evt);
            }
        });
        getContentPane().add(b_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 160, 70));

        b_productos.setBackground(new java.awt.Color(51, 153, 0));
        b_productos.setFont(new java.awt.Font("Dialog", 0, 22)); // NOI18N
        b_productos.setForeground(new java.awt.Color(255, 255, 255));
        b_productos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/productos.png"))); // NOI18N
        b_productos.setText("Productos");
        b_productos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_productosActionPerformed(evt);
            }
        });
        getContentPane().add(b_productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, -1, 70));

        b_ventas.setBackground(new java.awt.Color(51, 153, 0));
        b_ventas.setFont(new java.awt.Font("Dialog", 0, 22)); // NOI18N
        b_ventas.setForeground(new java.awt.Color(255, 255, 255));
        b_ventas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventas.png"))); // NOI18N
        b_ventas.setText("Ventas");
        b_ventas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_ventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_ventasActionPerformed(evt);
            }
        });
        getContentPane().add(b_ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 210, 150, -1));

        b_almacen.setBackground(new java.awt.Color(51, 153, 0));
        b_almacen.setFont(new java.awt.Font("Dialog", 0, 22)); // NOI18N
        b_almacen.setForeground(new java.awt.Color(255, 255, 255));
        b_almacen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/almacen.png"))); // NOI18N
        b_almacen.setText("Almacen");
        b_almacen.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_almacen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_almacenActionPerformed(evt);
            }
        });
        getContentPane().add(b_almacen, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 210, -1, -1));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 340, 110, 40));

        b_mail.setBackground(new java.awt.Color(51, 153, 0));
        b_mail.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_mail.setForeground(new java.awt.Color(255, 255, 255));
        b_mail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/email.png"))); // NOI18N
        b_mail.setText("Email");
        b_mail.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(b_mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, 100, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 350, 130, 40));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        l_fondo.setBackground(new java.awt.Color(51, 153, 0));
        l_fondo.setFont(new java.awt.Font("Dialog", 0, 22)); // NOI18N
        l_fondo.setForeground(new java.awt.Color(255, 255, 255));
        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_principal.jpg"))); // NOI18N
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -30, 1010, 440));

        menubar.setBackground(new java.awt.Color(0, 0, 0));
        menubar.setForeground(java.awt.Color.white);

        m_opciones.setBackground(new java.awt.Color(51, 153, 0));
        m_opciones.setBorder(null);
        m_opciones.setForeground(new java.awt.Color(255, 255, 255));
        m_opciones.setText("Opciones");
        m_opciones.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        opcion_abrir.setBackground(new java.awt.Color(51, 153, 0));
        opcion_abrir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        opcion_abrir.setForeground(new java.awt.Color(255, 255, 255));
        opcion_abrir.setText("Abrir");
        opcion_abrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcion_abrirActionPerformed(evt);
            }
        });
        m_opciones.add(opcion_abrir);

        opcion_guardar.setBackground(new java.awt.Color(51, 153, 0));
        opcion_guardar.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        opcion_guardar.setForeground(new java.awt.Color(255, 255, 255));
        opcion_guardar.setText("Guardar como");
        m_opciones.add(opcion_guardar);

        opcion_salir.setBackground(new java.awt.Color(51, 153, 0));
        opcion_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        opcion_salir.setForeground(new java.awt.Color(255, 255, 255));
        opcion_salir.setText("Salir");
        m_opciones.add(opcion_salir);

        menubar.add(m_opciones);

        m_ayuda.setBackground(new java.awt.Color(51, 153, 0));
        m_ayuda.setBorder(null);
        m_ayuda.setForeground(new java.awt.Color(255, 255, 255));
        m_ayuda.setText("Ayuda");
        m_ayuda.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

        acercade.setBackground(new java.awt.Color(51, 153, 0));
        acercade.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        acercade.setForeground(new java.awt.Color(255, 255, 255));
        acercade.setText("Acerca de");
        acercade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acercadeActionPerformed(evt);
            }
        });
        m_ayuda.add(acercade);

        menubar.add(m_ayuda);

        setJMenuBar(menubar);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //=================== METODOS ACTION LISTENER  =============================
   
    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null, 
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE); 

        if (respuesta == JOptionPane.YES_OPTION) { 
            System.exit(0); // salimos
        }
    }//GEN-LAST:event_b_salirActionPerformed
    private void opcion_abrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcion_abrirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcion_abrirActionPerformed

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        dispose();
        new VentanaLoggin().setVisible(true);
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_clientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_clientesActionPerformed
        dispose(); // cerramos ventana principal
        new VentanaClientes().setVisible(true);
    }//GEN-LAST:event_b_clientesActionPerformed
    
    
    private void acercadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acercadeActionPerformed
        String info = """
        📦 Nombre del Software: AlmacénPro+
        🧾 Versión: 1.0.3
        🛒 Descripción: Sistema de Gestión y Ventas para Almacenes

        © 2025 AlmacénPro+ - Todos los derechos reservados.
        
        📧 Soporte técnico: orionSystem@informatic.com
        ☎️ Teléfono: +56 9 48763064 
    """;

        JOptionPane.showMessageDialog(this, info, "Acerca de AlmacénPro+", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_acercadeActionPerformed

    private void b_productosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_productosActionPerformed
        dispose();
        new VentanaProductos().setVisible(true);  // abrimos ventana productos
    }//GEN-LAST:event_b_productosActionPerformed

    private void b_ventasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_ventasActionPerformed
        dispose();
        new VentanaVentasBoleta().setVisible(true);
    }//GEN-LAST:event_b_ventasActionPerformed

    private void b_almacenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_almacenActionPerformed
      dispose();
      new VentanaReportesVenta().setVisible(true);
    }//GEN-LAST:event_b_almacenActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventanaPrincipal(true).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem acercade;
    private javax.swing.JButton b_almacen;
    private javax.swing.JButton b_clientes;
    private javax.swing.JButton b_mail;
    private javax.swing.JButton b_productos;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_ventas;
    private javax.swing.JButton b_volver;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_nombremodulo;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JMenu m_ayuda;
    private javax.swing.JMenu m_opciones;
    private javax.swing.JMenuBar menubar;
    private javax.swing.JMenuItem opcion_abrir;
    private javax.swing.JMenuItem opcion_guardar;
    private javax.swing.JMenuItem opcion_salir;
    // End of variables declaration//GEN-END:variables
}
