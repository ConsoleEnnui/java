package ventanas;
import conexiones.Conexiones;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.SwingConstants;

import java.sql.Connection;


public class VentanaWindows extends javax.swing.JFrame {

    private int idUsuario;
    private int idCliente;

    public VentanaWindows(int idUsuario, int idCliente) {
        java.awt.Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        this.idUsuario = idUsuario;
        this.idCliente = idCliente;
        initComponents();
        mostrarDatosUsuario();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        matteBorder1 = new javax.swing.border.MatteBorder(null);
        dpn_escritorio = new javax.swing.JDesktopPane();
        l_bienvenida = new javax.swing.JLabel();
        logo_principal = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu_ingresar = new javax.swing.JMenu();
        m_caja = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        dpn_escritorio.setBorder(new javax.swing.border.MatteBorder(null));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N

        dpn_escritorio.setLayer(l_bienvenida, javax.swing.JLayeredPane.DEFAULT_LAYER);
        dpn_escritorio.setLayer(logo_principal, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout dpn_escritorioLayout = new javax.swing.GroupLayout(dpn_escritorio);
        dpn_escritorio.setLayout(dpn_escritorioLayout);
        dpn_escritorioLayout.setHorizontalGroup(
            dpn_escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dpn_escritorioLayout.createSequentialGroup()
                .addGroup(dpn_escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dpn_escritorioLayout.createSequentialGroup()
                        .addGap(581, 581, 581)
                        .addComponent(logo_principal, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(dpn_escritorioLayout.createSequentialGroup()
                        .addGap(420, 420, 420)
                        .addComponent(l_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(421, Short.MAX_VALUE))
        );
        dpn_escritorioLayout.setVerticalGroup(
            dpn_escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dpn_escritorioLayout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addComponent(logo_principal, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(l_bienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(596, Short.MAX_VALUE))
        );

        jMenu1.setText("Archivo");
        jMenuBar1.add(jMenu1);

        jMenu_ingresar.setText("Ingresar");

        m_caja.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/factura.png"))); // NOI18N
        m_caja.setText("Caja");
        m_caja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_cajaActionPerformed(evt);
            }
        });
        jMenu_ingresar.add(m_caja);

        jMenuBar1.add(jMenu_ingresar);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dpn_escritorio)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dpn_escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    //================== METODO MENU CAJA  =====================================
    private void m_cajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_cajaActionPerformed
        // Usa el idUsuario que fue pasado de la clase de login
        int idUsuario = this.idUsuario;  // El idUsuario de la instancia actual de VentanaCaja
        int idCliente = this.idCliente;

        // Crear la ventana interna con el idUsuario
        VentanaCaja ventanaInterna = new VentanaCaja(idUsuario);

        dpn_escritorio.add(ventanaInterna);  // Agregar la ventana interna al escritorio de VentanaCaja

        ventanaInterna.setVisible(true);
        ventanaInterna.setSize(dpn_escritorio.getSize());
        // Si quieres que la ventana interna se "activa" o se muestra por encima de otras
        try {
            ventanaInterna.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_m_cajaActionPerformed
    //================== METODO DE USUARIO =====================================
    private void mostrarDatosUsuario() {
        String sql = "SELECT nombre_usuario FROM usuarios WHERE id_usuario = ?";
        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String userName = rs.getString("nombre_usuario");
                l_bienvenida.setText("¡Bienvenido " + userName);

                // Estilo decorativo y profesional
                l_bienvenida.setForeground(new Color(0, 191, 255));
                l_bienvenida.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 30));  
                // Estilo adicional
                l_bienvenida.setOpaque(false);  
                l_bienvenida.setHorizontalAlignment(SwingConstants.CENTER);  
            } else {
                l_bienvenida.setText("Usuario no encontrado");
                l_bienvenida.setForeground(Color.RED);  // Error color rojo
                l_bienvenida.setFont(new Font("Arial", Font.PLAIN, 18));  
            }

        } catch (SQLException e) {
            e.printStackTrace();
            l_bienvenida.setText("Error al cargar usuario");
            l_bienvenida.setForeground(Color.RED);  // Color rojo
            l_bienvenida.setFont(new Font("Arial", Font.BOLD, 18));  
        }
    }
    
    //==========================================================================
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane dpn_escritorio;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenu_ingresar;
    private javax.swing.JLabel l_bienvenida;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JMenuItem m_caja;
    private javax.swing.border.MatteBorder matteBorder1;
    // End of variables declaration//GEN-END:variables
}
