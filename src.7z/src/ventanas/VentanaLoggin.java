package ventanas;

import conexiones.Conexiones;

import ventanas.VentanaWindows;
import Class.VentanaAdminModal;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingUtilities;

public class VentanaLoggin extends javax.swing.JFrame {

    private JPanel jPanel1;
    private int idCliente;

    public VentanaLoggin() {
        initComponents();
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);
        setLocationRelativeTo(null);
        setVisible(true);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        l_usuario = new javax.swing.JLabel();
        l_pass = new javax.swing.JLabel();
        campo_usuario = new javax.swing.JTextField();
        campo_pass = new javax.swing.JPasswordField();
        b_acceder = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_pieVentana = new javax.swing.JLabel();
        l_loggin = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        M_admin = new javax.swing.JMenu();
        Sub_Ingresar = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        jPopupMenu1.addMenuKeyListener(new javax.swing.event.MenuKeyListener() {
            public void menuKeyPressed(javax.swing.event.MenuKeyEvent evt) {
                jPopupMenu1MenuKeyPressed(evt);
            }
            public void menuKeyReleased(javax.swing.event.MenuKeyEvent evt) {
            }
            public void menuKeyTyped(javax.swing.event.MenuKeyEvent evt) {
            }
        });

        jMenuItem1.setText("jMenuItem1");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("jMenuItem2");
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Loggin de usuario");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_usuario.setBackground(new java.awt.Color(0, 0, 0));
        l_usuario.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        l_usuario.setForeground(new java.awt.Color(0, 0, 0));
        l_usuario.setText("Ingrese Usuario");
        getContentPane().add(l_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, 140, -1));

        l_pass.setBackground(new java.awt.Color(0, 0, 0));
        l_pass.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        l_pass.setForeground(new java.awt.Color(0, 0, 0));
        l_pass.setText("Ingrese Contraseña  ");
        getContentPane().add(l_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 370, 170, -1));

        campo_usuario.setBackground(new java.awt.Color(255, 255, 255));
        campo_usuario.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        campo_usuario.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(campo_usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 320, 200, 30));

        campo_pass.setBackground(new java.awt.Color(255, 255, 255));
        campo_pass.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        campo_pass.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(campo_pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 410, 200, 30));

        b_acceder.setBackground(new java.awt.Color(51, 153, 0));
        b_acceder.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_acceder.setForeground(new java.awt.Color(255, 255, 255));
        b_acceder.setText("Acceder");
        b_acceder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_acceder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_accederActionPerformed(evt);
            }
        });
        getContentPane().add(b_acceder, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 460, 130, 50));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setText("Salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 460, 80, 50));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 520, 130, 30));

        l_loggin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/loggin.jpeg"))); // NOI18N
        getContentPane().add(l_loggin, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, 180));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_login.jpg"))); // NOI18N
        l_fondo.setPreferredSize(new java.awt.Dimension(401, 588));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 401, 580));

        M_admin.setText("admin");

        Sub_Ingresar.setText("Ingresar");
        Sub_Ingresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Sub_IngresarMouseClicked(evt);
            }
        });
        M_admin.add(Sub_Ingresar);

        jMenuBar1.add(M_admin);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    int intentos = 0;
    private void b_accederActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_accederActionPerformed
        acceder();
    }//GEN-LAST:event_b_accederActionPerformed

    //=================== METODO ACCEDER USUARIO ===============================
    private void acceder() {
        String usuario = campo_usuario.getText();
        String pass = new String(campo_pass.getPassword());

        // Verificar si el usuario es "admin1"
        if (usuario.equals("admin1")) {
            JOptionPane.showMessageDialog(this, "Este login es solo para Usuarios");
            return;
        }

        String sql = "SELECT id_usuario FROM usuarios WHERE nombre_usuario = ? AND clave = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int idUsuario = rs.getInt("id_usuario");
                JOptionPane.showMessageDialog(null, "Login Correcto");

                VentanaWindows caja = new VentanaWindows(idUsuario, idCliente);
                caja.setVisible(true);
                this.dispose();
            } else {
                intentos++;
                if (intentos >= 3) {
                    JOptionPane.showMessageDialog(this, "Has superado el número de intentos. Acceso bloqueado.");
                    b_acceder.setEnabled(false); 
                    JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos. Intento " + intentos + " de 3.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al acceder a la base de datos");
        }
    }

    //=================== METODOS ACTION LISTENER ==============================
    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null, // variable de tipo entero 
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE); 

        if (respuesta == JOptionPane.YES_OPTION) { 
            System.exit(0); // salimos
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void jPopupMenu1MenuKeyPressed(javax.swing.event.MenuKeyEvent evt) {//GEN-FIRST:event_jPopupMenu1MenuKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPopupMenu1MenuKeyPressed

    private void Sub_IngresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Sub_IngresarMouseClicked
        // Mostrar ventana tipo UAC y esperar resultado
        VentanaAdminModal ventana = new VentanaAdminModal();
        ventana.setVisible(true);

        // Validar si el usuario presionó "Sí"
        if (!ventana.isAccesoConcedido()) {
            // Si dijo que NO, salir del método
            return;
        }
        int intentos = 0;

        Connection conexion = Conexiones.conectar();
        PreparedStatement consulta;
        ResultSet resultado;

        while (intentos < 3) {
            JPasswordField passwordField = new JPasswordField();
            SwingUtilities.invokeLater(() -> passwordField.requestFocusInWindow());

            int option = JOptionPane.showConfirmDialog(
                    null,
                    passwordField,
                    "Ingrese la contraseña de administrador",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (option == JOptionPane.OK_OPTION) {
                String contrasenia = new String(passwordField.getPassword());

                try {
                    String sql = "SELECT clave FROM usuarios WHERE nombre_usuario = ? AND clave = ?";
                    consulta = conexion.prepareStatement(sql);
                    consulta.setString(1, "admin1");
                    consulta.setString(2, contrasenia);

                    resultado = consulta.executeQuery();

                    if (resultado.next()) {
                        JOptionPane.showMessageDialog(null, "LOGIN CORRECTO", "LOGIN", JOptionPane.INFORMATION_MESSAGE);
                        new ventanaPrincipal(true).setVisible(true);
                        dispose();
                        break;
                    } else {
                        intentos++;

                        if (intentos == 3) {
                            JOptionPane.showMessageDialog(null,
                                    "CANTIDAD DE INTENTOS AGOTADAS.\nSU CUENTA HA SIDO BLOQUEADA\nCONTACTE A SOPORTE",
                                    "AVISO", JOptionPane.WARNING_MESSAGE);
                        } else {
                            int intentosRestantes = 3 - intentos;
                            JOptionPane.showMessageDialog(null,
                                    "CONTRASEÑA INCORRECTA\nQUEDAN " + intentosRestantes + " INTENTOS. INTENTE DE NUEVO...",
                                    "ERROR",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                    }

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "ERROR EN LA CONSULTA", "ERROR", JOptionPane.WARNING_MESSAGE);
                    break;
                }

            } else {
                break;
            }
        }

    }//GEN-LAST:event_Sub_IngresarMouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaLoggin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaLoggin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaLoggin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaLoggin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaLoggin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu M_admin;
    private javax.swing.JMenu Sub_Ingresar;
    private javax.swing.JButton b_acceder;
    private javax.swing.JButton b_salir;
    private javax.swing.JPasswordField campo_pass;
    private javax.swing.JTextField campo_usuario;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_loggin;
    private javax.swing.JLabel l_pass;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel l_usuario;
    // End of variables declaration//GEN-END:variables
}
