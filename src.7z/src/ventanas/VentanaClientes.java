package ventanas;
import conexiones.Conexiones;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

/**
 *
 * @author jfran
 */
public class VentanaClientes extends javax.swing.JFrame {

    private int idUsuario;

    public VentanaClientes() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass()
        .getResource("/imagenes/almacen1.jpg")); // icono en la interfaz
        setIconImage(icono); // establecemos el icono  
        Mostrar("clientes");
        
        // Estilo para idCliente
        SwingUtilities.invokeLater(() -> {
            t_idCliente.requestFocusInWindow();
            // Sitúa el cursor al final (o al inicio si prefieres)
            t_idCliente.setCaretPosition(t_idCliente.getText().length());
            // Asegura que el caret parpadee cada 500 ms (valor en ms)
            t_idCliente.getCaret().setBlinkRate(500);
        });

    }
    
    //================== METODO MOSTRAR TABLA ==================================
    public void Mostrar(String tabla) {
        String sql = "SELECT * FROM " + tabla;
        Connection con = conexion.conectar();

        if (con == null) {
            JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Definimos el modelo de la tabla con las columnas correctas
        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{"id_cliente", "Rut", "Nombre", "Direccion", "Telefono"} // Corregido para incluir la columna rut
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Las celdas no son editables
            }
        };

        // Configurar el header de la tabla
        tabla_clientes.getTableHeader().setFont(new Font("Verdana", Font.BOLD, 18));
        tabla_clientes.setModel(modelo);

        // Hacer que las columnas no sean redimensionables
        for (int f = 0; f < tabla_clientes.getColumnCount(); f++) {
            tabla_clientes.getColumnModel().getColumn(f).setResizable(false);
        }

        // Arreglo para almacenar los datos de cada fila
        String[] datos = new String[5]; // Cambié el tamaño a 5 para incluir la columna 'rut'

        try {
            Statement consulta = con.createStatement();
            ResultSet resultado = consulta.executeQuery(sql);

            if (resultado.next()) { // Mover esto aquí
                int idCliente = resultado.getInt("id_cliente"); // Obtenemos el ID válido
            }

            while (resultado.next()) {
                datos[0] = resultado.getString("id_cliente"); // Cambio para usar el nombre de la columna
                datos[1] = resultado.getString("rut"); 
                datos[2] = resultado.getString("nombre");
                datos[3] = resultado.getString("direccion");
                datos[4] = resultado.getString("telefono");
                modelo.addRow(datos);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los datos", "Error", JOptionPane.ERROR_MESSAGE);
        }

        centrarTexto(tabla_clientes); 
    }

    //============= Método para centrar los valores en cada celda ==============
    public void centrarTexto(JTable tabla) {
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centrado);
        }
    }
    //================== METODOS BUSCAR CLIENTE ================================
    public void Buscar_Id_Cliente() {
        String idCliente = t_idCliente.getText().trim();
        if (idCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese Id del Cliente", "AVISO", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "SELECT * FROM clientes WHERE id_cliente = ?";
        DefaultTableModel modelo = (DefaultTableModel) tabla_clientes.getModel();
        modelo.setRowCount(0); // Limpiar la tabla antes de mostrar resultados.

        try (Connection con = conexion.conectar(); PreparedStatement consulta = con.prepareStatement(sql)) {
            consulta.setString(1, idCliente);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String[] datos = {
                    resultado.getString("id_cliente"),
                    resultado.getString("rut"),
                    resultado.getString("nombre"),
                    resultado.getString("direccion"),
                    resultado.getString("telefono"),};
                modelo.addRow(datos); // Agregar la fila a la tabla
                configurarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "CLIENTE NO EXISTE", "RESULTADO DE BUSQUEDA", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar cliente: " + e.getMessage(), "ERROR: ", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void Buscar_nombre() {
        String NombreCliente = t_nombre.getText().trim();
        if (NombreCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NOMBRE DEL CLIENTE", "AVISO", JOptionPane.WARNING_MESSAGE);
            return; 
        }

        String sql = "SELECT * FROM clientes WHERE nombre LIKE ?";
        DefaultTableModel modelo = (DefaultTableModel) tabla_clientes.getModel();
        // Después de asignar el modelo de la tabla
        tabla_clientes.getColumnModel().getColumn(1).setPreferredWidth(80); 

        modelo.setRowCount(0); 

        try (Connection con = conexion.conectar(); PreparedStatement consulta = con.prepareStatement(sql)) {
            consulta.setString(1, "%" + NombreCliente + "%");
            ResultSet resultado = consulta.executeQuery();

            boolean encontrado = false;

            while (resultado.next()) {
                String[] datos = {
                    resultado.getString("id_cliente"),
                    resultado.getString("rut"),
                    resultado.getString("nombre"),
                    resultado.getString("direccion"),
                    resultado.getString("telefono"),};
                modelo.addRow(datos);
                encontrado = true;
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "CLIENTE NO ENCONTRADO", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BUSQUEDA: " + e.getMessage(), "RESULTADO", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //================== METODOS AUXILIARES ====================================
    private void configurarTabla() {
        tabla_clientes.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla_clientes.setEnabled(true); // permitir selección visual

        tabla_clientes.setRowSelectionAllowed(true);
        tabla_clientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tabla_clientes.setSelectionBackground(new Color(0, 120, 215)); // azul
        tabla_clientes.setSelectionForeground(Color.WHITE); // texto blanco
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b_borrar = new javax.swing.JButton();
        b_insertar = new javax.swing.JButton();
        b_actualizar = new javax.swing.JButton();
        t_nombre = new javax.swing.JTextField();
        t_idCliente = new javax.swing.JTextField();
        l_idCliente = new javax.swing.JLabel();
        l_nombreCliente = new javax.swing.JLabel();
        b_buscar = new javax.swing.JButton();
        t_clientes = new javax.swing.JScrollPane();
        tabla_clientes = new javax.swing.JTable();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_modulo = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        b_refresh = new javax.swing.JButton();
        logo_principal = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        b_borrar.setBackground(new java.awt.Color(51, 153, 0));
        b_borrar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_borrar.setForeground(new java.awt.Color(255, 255, 255));
        b_borrar.setText("Borrar");
        b_borrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_borrarActionPerformed(evt);
            }
        });
        getContentPane().add(b_borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 170, 110, 40));

        b_insertar.setBackground(new java.awt.Color(51, 153, 0));
        b_insertar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_insertar.setForeground(new java.awt.Color(255, 255, 255));
        b_insertar.setText("Insertar");
        b_insertar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_insertarActionPerformed(evt);
            }
        });
        getContentPane().add(b_insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 110, 40));

        b_actualizar.setBackground(new java.awt.Color(51, 153, 0));
        b_actualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_actualizar.setForeground(new java.awt.Color(255, 255, 255));
        b_actualizar.setText("Actualizar");
        b_actualizar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(b_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 110, 40));

        t_nombre.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 180, 130, -1));

        t_idCliente.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 120, 50, -1));

        l_idCliente.setBackground(new java.awt.Color(51, 153, 0));
        l_idCliente.setForeground(new java.awt.Color(0, 0, 0));
        l_idCliente.setText("Nombre");
        getContentPane().add(l_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 180, 70, -1));

        l_nombreCliente.setBackground(new java.awt.Color(51, 153, 0));
        l_nombreCliente.setForeground(new java.awt.Color(0, 0, 0));
        l_nombreCliente.setText("idCliente");
        getContentPane().add(l_nombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 130, 70, -1));

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(b_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 120, 120, 90));

        tabla_clientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        t_clientes.setViewportView(tabla_clientes);

        getContentPane().add(t_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 840, 270));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 520, 110, 40));

        l_modulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_modulo.setForeground(new java.awt.Color(0, 102, 102));
        l_modulo.setText("Modulo de Clientes");
        getContentPane().add(l_modulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 530, 130, 30));

        b_refresh.setBackground(new java.awt.Color(204, 204, 204));
        b_refresh.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        b_refresh.setForeground(new java.awt.Color(255, 255, 255));
        b_refresh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando (5).png"))); // NOI18N
        b_refresh.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_refreshActionPerformed(evt);
            }
        });
        getContentPane().add(b_refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 240, 40, 40));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_clientes.jpg"))); // NOI18N
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1150, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //================== METODOS ACTION LISTENER ===============================
    private void b_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_borrarActionPerformed
        new VentanaBorrarClientes().setVisible(true);;
    }//GEN-LAST:event_b_borrarActionPerformed

    private void b_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_actualizarActionPerformed

        new VentanaActualizaClientes().setVisible(true);
    }//GEN-LAST:event_b_actualizarActionPerformed

    private void b_insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_insertarActionPerformed
        new VentanaInsertarClientes().setVisible(true); // accedemos a ventana Insertar

    }//GEN-LAST:event_b_insertarActionPerformed

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        new ventanaPrincipal(true).setVisible(true);
        dispose();
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null,
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        if (!t_idCliente.getText().isEmpty()) {
            Buscar_Id_Cliente();
        } else if (!t_nombre.getText().isEmpty()) {
            Buscar_nombre();
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR ID O NOMBRE CLIENTE",
                    "AVISO", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_b_buscarActionPerformed

    private void b_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_refreshActionPerformed
        Mostrar("clientes");
        t_idCliente.setText("");
        t_nombre.setText("");

    }//GEN-LAST:event_b_refreshActionPerformed

    /**
     * @param args the command line arguments
     */
    
    Conexiones conexion = new Conexiones();
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_actualizar;
    private javax.swing.JButton b_borrar;
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_insertar;
    private javax.swing.JButton b_refresh;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_volver;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idCliente;
    private javax.swing.JLabel l_modulo;
    private javax.swing.JLabel l_nombreCliente;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JScrollPane t_clientes;
    private javax.swing.JTextField t_idCliente;
    private javax.swing.JTextField t_nombre;
    private javax.swing.JTable tabla_clientes;
    // End of variables declaration//GEN-END:variables
}
