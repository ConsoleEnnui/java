package ventanas;

import conexiones.Conexiones;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableCellRenderer;
import java.sql.PreparedStatement;
import java.sql.Connection;

import java.awt.Toolkit;
import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class VentanaVentasBoleta extends javax.swing.JFrame {

    public VentanaVentasBoleta() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        java.awt.Image icono = Toolkit.getDefaultToolkit().getImage(getClass()
                .getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);  
        mostrar();

    }

    //=================== METODO MOSTRAR DATOS EN TABLA ========================
    public void mostrar() {
        String sql = """
        SELECT 
            c.id_cliente,
            c.nombre,
            c.rut,
            COUNT(DISTINCT v.id_venta) + COUNT(DISTINCT rv.id_reportev) AS cantidad_boletas
        FROM clientes c
        LEFT JOIN ventas v ON c.id_cliente = v.id_cliente
        LEFT JOIN reportesventa rv ON c.id_cliente = rv.id_cliente
        GROUP BY c.id_cliente, c.nombre, c.rut
    """;

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{"ID CLIENTE", "NOMBRE", "RUT", "N° BOLETAS"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla_ventas.setModel(modelo);

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("rut"),
                    rs.getInt("cantidad_boletas")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error:", JOptionPane.ERROR_MESSAGE);
        }
    }

    //==================== METODO BUSCAR CLIENTES ==============================
    public void BuscaCliente() {
        String NombreCliente = t_nomCliente.getText();
        if (NombreCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NOMBRE DE CLIENTE", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = """
        SELECT 
            c.id_cliente,
            c.nombre,
            c.rut,
            COUNT(DISTINCT v.id_venta) + COUNT(DISTINCT rv.id_reportev) AS cantidad_boletas
        FROM clientes c
        LEFT JOIN ventas v ON c.id_cliente = v.id_cliente
        LEFT JOIN reportesventa rv ON c.id_cliente = rv.id_cliente
        WHERE c.nombre LIKE ?
        GROUP BY c.id_cliente, c.nombre, c.rut
    """;

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{"ID CLIENTE", "NOMBRE", "RUT", "CANTIDAD BOLETAS"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla_ventas.setModel(modelo);

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + NombreCliente + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("rut"),
                    rs.getInt("cantidad_boletas")
                });
            }

            if (modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "CLIENTE NO EXISTE", "RESULTADO DE BÚSQUEDA",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            limpiar();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BÚSQUEDA\n" + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarID() {
        String strID = t_idCliente.getText().trim();

        if (strID.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR UN ID DE CLIENTE", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idCliente;
        try {
            idCliente = Integer.parseInt(strID);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "El ID debe ser un número entero", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = """
        SELECT 
            c.id_cliente,
            c.nombre,
            c.rut,
            COUNT(DISTINCT v.id_venta) + COUNT(DISTINCT rv.id_reportev) AS cantidad_boletas
        FROM clientes c
        LEFT JOIN ventas v ON c.id_cliente = v.id_cliente
        LEFT JOIN reportesventa rv ON c.id_cliente = rv.id_cliente
        WHERE c.id_cliente = ?
        GROUP BY c.id_cliente, c.nombre, c.rut
    """;

        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new Object[]{"ID CLIENTE", "NOMBRE", "RUT", "CANTIDAD BOLETAS"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla_ventas.setModel(modelo);

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("rut"),
                    rs.getInt("cantidad_boletas")
                });
            }

            limpiar();

            if (modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ CLIENTE CON ESE ID", "SIN RESULTADOS",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BÚSQUEDA\n" + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //==================== METODOS ACCION LISTENER =============================
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        t_idCliente = new javax.swing.JTextField();
        t_nomCliente = new javax.swing.JTextField();
        l_idCliente = new javax.swing.JLabel();
        l_nomCliente = new javax.swing.JLabel();
        b_buscar = new javax.swing.JButton();
        t_clientes = new javax.swing.JScrollPane();
        tabla_ventas = new javax.swing.JTable();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_modulo = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        b_refresh1 = new javax.swing.JButton();
        logo_principal = new javax.swing.JLabel();
        b_ver = new javax.swing.JButton();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MODULO DE VENTAS");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        t_idCliente.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 120, 60, 30));

        t_nomCliente.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_nomCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 160, 130, 30));

        l_idCliente.setBackground(new java.awt.Color(51, 153, 0));
        l_idCliente.setForeground(new java.awt.Color(0, 0, 0));
        l_idCliente.setText("id");
        getContentPane().add(l_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 120, 30, 30));

        l_nomCliente.setBackground(new java.awt.Color(51, 153, 0));
        l_nomCliente.setForeground(new java.awt.Color(0, 0, 0));
        l_nomCliente.setText("Nombre clliente");
        getContentPane().add(l_nomCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 166, 90, 30));

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(b_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, 110, 40));

        tabla_ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "IDCLIENTE", "NOMBRE", "RUT", "N  BOLETA"
            }
        ));
        t_clientes.setViewportView(tabla_ventas);

        getContentPane().add(t_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 580, 270));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 520, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 520, 110, 40));

        l_modulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_modulo.setForeground(new java.awt.Color(0, 102, 102));
        l_modulo.setText("Modulo de Ventas");
        getContentPane().add(l_modulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, -1, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 520, 130, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Buscar Boleta:  ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, -1, -1));

        b_refresh1.setBackground(new java.awt.Color(204, 204, 204));
        b_refresh1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        b_refresh1.setForeground(new java.awt.Color(255, 255, 255));
        b_refresh1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando (5).png"))); // NOI18N
        b_refresh1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_refresh1ActionPerformed(evt);
            }
        });
        getContentPane().add(b_refresh1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 230, 40, 40));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        b_ver.setBackground(new java.awt.Color(51, 153, 0));
        b_ver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_ver.setForeground(new java.awt.Color(255, 255, 255));
        b_ver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ver.png"))); // NOI18N
        b_ver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_ver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_verActionPerformed(evt);
            }
        });
        getContentPane().add(b_ver, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 310, 70, 60));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_ventas.jpg"))); // NOI18N
        l_fondo.setToolTipText("");
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        dispose();
        new ventanaPrincipal(true).setVisible(true);
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null,
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        if (!t_nomCliente.getText()
                .isEmpty()) {
            BuscaCliente();
        } else if (!t_idCliente.getText()
                .isEmpty()) {
            buscarID();
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NOMBRE DE CLIENTE\n"
                    + "O DE FACTURA A BUSCAR", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    //====================== METODOS AUXILIARES ================================
    private void configurarTabla() {
        tabla_ventas.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla_ventas.setEnabled(true); // permitir selección visual

        tabla_ventas.setRowSelectionAllowed(true);
        tabla_ventas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tabla_ventas.setSelectionBackground(new Color(0, 120, 215)); // azul
        tabla_ventas.setSelectionForeground(Color.WHITE); // texto blanco
    }

    public void centrarTexto(JTable tabla) {
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centrado);
        }

    }//GEN-LAST:event_b_buscarActionPerformed

    private void limpiar() {
        t_nomCliente.setText("");
        t_idCliente.setText("");
    }

    private void b_refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_refresh1ActionPerformed
        mostrar();
    }//GEN-LAST:event_b_refresh1ActionPerformed

    private void b_verActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_verActionPerformed
        int filaSeleccionada = tabla_ventas.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un cliente para ver sus boletas",
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int idCliente = Integer.parseInt(tabla_ventas.getValueAt(filaSeleccionada, 0).toString());
            String nombreCliente = tabla_ventas.getValueAt(filaSeleccionada, 1).toString();

            VentanaVentas ventas = new VentanaVentas();
            ventas.setTitle("Boletas de " + nombreCliente);
            ventas.cargarBoletasPorCliente(idCliente);
            ventas.setVisible(true);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                    "Error al obtener el ID del cliente",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_b_verActionPerformed

    //====================== CONECCION =========================================
    Conexiones conexion = new Conexiones();
    java.sql.Connection con = conexion.conectar();

    //=================== METODO MAIN  =========================================
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaVentasBoleta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaVentasBoleta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaVentasBoleta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaVentasBoleta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaVentasBoleta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_refresh1;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_ver;
    private javax.swing.JButton b_volver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idCliente;
    private javax.swing.JLabel l_modulo;
    private javax.swing.JLabel l_nomCliente;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JScrollPane t_clientes;
    private javax.swing.JTextField t_idCliente;
    private javax.swing.JTextField t_nomCliente;
    private javax.swing.JTable tabla_ventas;
    // End of variables declaration//GEN-END:variables
}
