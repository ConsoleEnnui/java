package ventanas;

import conexiones.Conexiones;

import ventanas.VentanaReportesVenta;
import ventanas.VentanaProductos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Component;
import java.awt.Toolkit;

import java.text.SimpleDateFormat;

import javax.swing.JOptionPane;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.File;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JDialog;
import java.math.BigDecimal;
import java.security.Timestamp;

import javax.swing.*;

public class VentanaCaja extends javax.swing.JInternalFrame {

    private final Map<String, Integer> productosStockMap = new HashMap<>();
    private Map<String, Integer> categoriasMap = new HashMap<>();
    double totalAcumulado = 0.0;
    private VentanaProductos ventanaProductos;
    private VentanaReportesVenta ventanaReportes;
    // Suponiendo que tienes un JLabel en tu interfaz, por ejemplo, lblIdUsuario
    private JLabel lblIdUsuario;
    private final Map<String, Boolean> categoriasConStock = new HashMap<>();
    private String horaInicioVenta = java.time.LocalTime.now().toString();
    private final int idUsuario;
    private int idCliente;
    private final String horaInicio;
    private JTable tabla_productos;

    public VentanaCaja(int idUsuario) {
        initComponents();
        java.awt.Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        configurarVentana();
        TexfieldDesactivados();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        this.idCliente = idCliente;
        this.idUsuario = idUsuario;
        //this.idCliente = idCliente;
        cargarCategorias();
        setStock();
        j_date.setDate(new Date());

        mostrarDatosUsuario();
        // Capturar la hora actual al abrir la ventana
        ///SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        this.horaInicio = sdf.format(new Date());
    }

    //=================== METODOS USUARIO Y CLIENTE ============================
    public String[] obtenerDatosUsuario(int idUsuario) {
        String[] datos = new String[2]; // [0] = nombre, [1] = departamento

        String sql = "SELECT nombre, departamento FROM usuarios WHERE id_usuario = ?";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                datos[0] = rs.getString("nombre");
                datos[1] = rs.getString("departamento");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al obtener datos del usuario:\n" + e.getMessage());
        }

        return datos;
    }

    private void mostrarDatosUsuario() {
        String sql = "SELECT nombre_usuario FROM usuarios WHERE id_usuario = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario); // usa el id recibido en el constructor
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String userName = rs.getString("nombre_usuario");
                lb_idUsuario.setText("ID Usuario: " + idUsuario + " | Nombre: " + userName);
            } else {
                lb_idUsuario.setText("Usuario no encontrado");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            lb_idUsuario.setText("Error al cargar usuario");
        }
    }

    private String obtenerNombreCliente(int idCliente) {
        String nombre = "";
        String sql = "SELECT nombre FROM clientes WHERE id_cliente = ?";

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    nombre = rs.getString("nombre");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al obtener nombre del cliente:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        return nombre;
    }

    public void BuscarCliente() {
        String rutIngresado = t_rut.getText().trim();
        String nombreIngresado = t_buscarNombre.getText().trim().toLowerCase();

        // Validación
        if (rutIngresado.isEmpty() && nombreIngresado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese RUT o NOMBRE del cliente", "AVISO",
                    JOptionPane.WARNING_MESSAGE);
            t_rut.requestFocus();
            return;
        }

        String sql;
        boolean buscarPorRut = false;

        if (!rutIngresado.isEmpty()) {
            sql = "SELECT * FROM clientes WHERE rut = ?";
            buscarPorRut = true;
        } else {
            sql = "SELECT * FROM clientes WHERE LOWER(nombre) LIKE ?";
        }

        try {
            Connection con = Conexiones.conectar();
            PreparedStatement consulta = con.prepareStatement(sql);

            if (buscarPorRut) {
                consulta.setString(1, rutIngresado);
            } else {
                consulta.setString(1, "%" + nombreIngresado + "%");
            }

            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                String nombre = resultado.getString("nombre");
                String rut = resultado.getString("rut");
                int idCliente = resultado.getInt("id_cliente");  // Obtener el ID del cliente

                // Asignar el ID del cliente a la variable idCliente
                this.idCliente = idCliente;  // Asegúrate de tener la variable idCliente en tu clase

                t_nombre.setText(nombre);
                t_direccion.setText(resultado.getString("direccion"));
                t_telefono.setText(resultado.getString("telefono"));
                t_rut.setText(rut);

                lblBienvenida.setText("Cliente encontrado: " + nombre);
                lblBienvenida.setForeground(new Color(0, 102, 102));
                lbrut.setText("RUT: " + rut);
                lbrut.setForeground(new Color(0, 153, 0));
                t_buscarNombre.setText("");
                t_rut.setText("");
            } else {
                t_nombre.setText("");
                t_direccion.setText("");
                t_telefono.setText("");

                lblBienvenida.setText("Cliente no encontrado.");
                lbrut.setText("No existe.");
                lbrut.setForeground(Color.RED);
            }

            resultado.close();
            consulta.close();
            con.close();

            // Limpiar campos de búsqueda
            t_buscarNombre.setText("");
            t_rut.requestFocus();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar cliente: " + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private String obtenerIdClientePorRUT(String rut) {
        String idCliente = null;
        String sql = "SELECT id_cliente FROM clientes WHERE rut = ?";

        try (Connection conn = Conexiones.conectar(); PreparedStatement consulta = conn.prepareStatement(sql)) {

            consulta.setString(1, rut);
            try (ResultSet resultado = consulta.executeQuery()) {
                if (resultado.next()) {
                    idCliente = resultado.getString("id_cliente");
                }
            }

        } catch (SQLException e) {
            System.out.println("Error obteniendo ID del cliente por RUT: " + e.getMessage());
            e.printStackTrace();
        }

        return idCliente != null ? idCliente : "No encontrado";
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JD_IMPRIMIR = new javax.swing.JDialog();
        b_imprimir = new javax.swing.JButton();
        l_rut = new javax.swing.JLabel();
        t_rut = new javax.swing.JTextField();
        l_nombrebuscar = new javax.swing.JLabel();
        t_buscarNombre = new javax.swing.JTextField();
        l_categoria = new javax.swing.JLabel();
        combo_categoria = new javax.swing.JComboBox<>();
        btn_limpiar = new javax.swing.JButton();
        b_buscar = new javax.swing.JButton();
        l_telefono = new javax.swing.JLabel();
        t_nombre = new javax.swing.JTextField();
        l_direccion = new javax.swing.JLabel();
        t_direccion = new javax.swing.JTextField();
        l_nombre = new javax.swing.JLabel();
        t_telefono = new javax.swing.JTextField();
        l_cantidad = new javax.swing.JLabel();
        t_cantidad = new javax.swing.JTextField();
        combo_productos = new javax.swing.JComboBox<>();
        l_productos = new javax.swing.JLabel();
        btn_generar = new javax.swing.JButton();
        btn_agregar = new javax.swing.JButton();
        Total = new javax.swing.JLabel();
        t_total = new javax.swing.JTextField();
        l_fecha_ingreso = new javax.swing.JLabel();
        j_date = new com.toedter.calendar.JDateChooser();
        lblBienvenida = new javax.swing.JLabel();
        lbrut = new javax.swing.JLabel();
        btn_MasProducto = new javax.swing.JRadioButton();
        btn_desconexion = new javax.swing.JButton();
        lb_idUsuario = new javax.swing.JLabel();
        scrollbar1 = new java.awt.Scrollbar();
        t_stock = new javax.swing.JTextField();
        l_stock = new javax.swing.JLabel();

        b_imprimir.setBackground(new java.awt.Color(51, 153, 0));
        b_imprimir.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        b_imprimir.setForeground(new java.awt.Color(255, 255, 255));
        b_imprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/factura.png"))); // NOI18N
        b_imprimir.setText("Imprimir");
        b_imprimir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_imprimirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JD_IMPRIMIRLayout = new javax.swing.GroupLayout(JD_IMPRIMIR.getContentPane());
        JD_IMPRIMIR.getContentPane().setLayout(JD_IMPRIMIRLayout);
        JD_IMPRIMIRLayout.setHorizontalGroup(
            JD_IMPRIMIRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 418, Short.MAX_VALUE)
            .addGroup(JD_IMPRIMIRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(JD_IMPRIMIRLayout.createSequentialGroup()
                    .addGap(0, 124, Short.MAX_VALUE)
                    .addComponent(b_imprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 124, Short.MAX_VALUE)))
        );
        JD_IMPRIMIRLayout.setVerticalGroup(
            JD_IMPRIMIRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 248, Short.MAX_VALUE)
            .addGroup(JD_IMPRIMIRLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(JD_IMPRIMIRLayout.createSequentialGroup()
                    .addGap(0, 104, Short.MAX_VALUE)
                    .addComponent(b_imprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 104, Short.MAX_VALUE)))
        );

        setClosable(true);
        setTitle("JInternal Caja");
        setPreferredSize(new java.awt.Dimension(910, 500));

        l_rut.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_rut.setForeground(new java.awt.Color(0, 102, 102));
        l_rut.setText("Rut");

        t_rut.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_rut.setForeground(new java.awt.Color(0, 102, 102));

        l_nombrebuscar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_nombrebuscar.setForeground(new java.awt.Color(0, 102, 102));
        l_nombrebuscar.setText("Nombre");

        t_buscarNombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_buscarNombre.setForeground(new java.awt.Color(0, 102, 102));

        l_categoria.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_categoria.setForeground(new java.awt.Color(0, 102, 102));
        l_categoria.setText("Categoria");

        combo_categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_categoriaActionPerformed(evt);
            }
        });

        btn_limpiar.setBackground(new java.awt.Color(51, 153, 0));
        btn_limpiar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        btn_limpiar.setText("Limpiar");
        btn_limpiar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpiarActionPerformed(evt);
            }
        });

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });

        l_telefono.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_telefono.setForeground(new java.awt.Color(0, 102, 102));
        l_telefono.setText("Telefono");

        t_nombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_nombre.setForeground(new java.awt.Color(51, 21, 221));

        l_direccion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_direccion.setForeground(new java.awt.Color(0, 102, 102));
        l_direccion.setText("Direccion");

        t_direccion.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_direccion.setForeground(new java.awt.Color(0, 102, 102));

        l_nombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_nombre.setForeground(new java.awt.Color(0, 102, 102));
        l_nombre.setText("Nombre");

        t_telefono.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_telefono.setForeground(new java.awt.Color(0, 102, 102));

        l_cantidad.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_cantidad.setForeground(new java.awt.Color(0, 102, 102));
        l_cantidad.setText("Cantidad");

        t_cantidad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_cantidad.setForeground(new java.awt.Color(0, 102, 102));

        combo_productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_productosActionPerformed(evt);
            }
        });

        l_productos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_productos.setForeground(new java.awt.Color(0, 102, 102));
        l_productos.setText("Productos");

        btn_generar.setBackground(new java.awt.Color(51, 153, 0));
        btn_generar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_generar.setForeground(new java.awt.Color(255, 255, 255));
        btn_generar.setText("Generar");
        btn_generar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_generar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generarActionPerformed(evt);
            }
        });

        btn_agregar.setBackground(new java.awt.Color(51, 153, 0));
        btn_agregar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_agregar.setForeground(new java.awt.Color(255, 255, 255));
        btn_agregar.setText("Agregar");
        btn_agregar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_agregarActionPerformed(evt);
            }
        });

        Total.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        Total.setForeground(new java.awt.Color(0, 102, 102));
        Total.setText("Total");

        t_total.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_total.setForeground(new java.awt.Color(51, 21, 221));

        l_fecha_ingreso.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_fecha_ingreso.setForeground(new java.awt.Color(0, 102, 102));
        l_fecha_ingreso.setText("Fecha ");

        lblBienvenida.setBackground(new java.awt.Color(57, 255, 20));
        lblBienvenida.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        lbrut.setBackground(new java.awt.Color(57, 255, 20));
        lbrut.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

        btn_MasProducto.setText("+");
        btn_MasProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MasProductoActionPerformed(evt);
            }
        });

        btn_desconexion.setBackground(new java.awt.Color(153, 153, 153));
        btn_desconexion.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_desconexion.setForeground(new java.awt.Color(153, 0, 0));
        btn_desconexion.setText("Desconectar");
        btn_desconexion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_desconexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_desconexionActionPerformed(evt);
            }
        });

        lb_idUsuario.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        lb_idUsuario.setForeground(new java.awt.Color(0, 153, 0));
        lb_idUsuario.setText("iD");

        t_stock.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        t_stock.setForeground(new java.awt.Color(51, 21, 221));
        t_stock.setBorder(new javax.swing.border.MatteBorder(null));

        l_stock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        l_stock.setForeground(new java.awt.Color(0, 102, 102));
        l_stock.setText("Stock");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(lb_idUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(107, 107, 107)
                        .addComponent(b_buscar)
                        .addGap(33, 33, 33)
                        .addComponent(l_rut, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47)
                        .addComponent(t_rut, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(lblBienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(291, 291, 291)
                        .addComponent(l_nombrebuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addComponent(t_buscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(lbrut, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(l_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addComponent(t_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(l_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(t_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(l_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(22, 22, 22)
                                .addComponent(t_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(54, 54, 54)
                                .addComponent(btn_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(btn_MasProducto))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(l_productos, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(22, 22, 22)
                                    .addComponent(combo_productos, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(136, 136, 136)
                                    .addComponent(btn_limpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(l_fecha_ingreso, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(2, 2, 2)
                                    .addComponent(j_date, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(70, 70, 70)
                                    .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(12, 12, 12)
                                    .addComponent(t_total, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(19, 19, 19)
                                    .addComponent(btn_generar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(btn_desconexion, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(l_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(t_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(combo_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(l_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(t_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(scrollbar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lb_idUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(l_rut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t_rut, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblBienvenida, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(l_nombrebuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(t_buscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addComponent(lbrut, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(l_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(t_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(t_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(l_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(l_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(11, 11, 11)
                                        .addComponent(l_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(17, 17, 17)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(l_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(t_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(combo_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(scrollbar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(l_productos, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combo_productos, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_limpiar)
                        .addGap(14, 14, 14)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_agregar)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btn_MasProducto)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_fecha_ingreso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(j_date, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_generar))
                .addGap(28, 28, 28)
                .addComponent(btn_desconexion)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //=================== METODOS ACTION LISTNER ===============================
    private void btn_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btn_limpiarActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        String rut = t_rut.getText().trim();
        String nombre = t_buscarNombre.getText().trim();

        if (!rut.isEmpty()) {
            BuscarCliente();
        } else if (!nombre.isEmpty()) {
            BuscarCliente();
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR RUT O NOMBRE DEL CLIENTE",
                    "AVISO", JOptionPane.WARNING_MESSAGE);
            t_rut.requestFocus();
        }
    }//GEN-LAST:event_b_buscarActionPerformed

    private void btn_generarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generarActionPerformed
        // Primero verificar que el cliente existe en la base de datos
        if (!verificarExistenciaCliente(idCliente)) {
            JOptionPane.showMessageDialog(
                    this,
                    "El cliente con ID " + idCliente + " no existe en la base de datos.\n"
                    + "Por favor, seleccione un cliente válido o regístrelo primero.",
                    "Error de Referencia",
                    JOptionPane.ERROR_MESSAGE
            );
            return; // Detener la ejecución si el cliente no existe
        }

        int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Desea confirmar la generación de la boleta?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (opcion == JOptionPane.YES_OPTION) {
            Imprimir(idUsuario, idCliente);
            generarBoleta();
        }
    }

    private boolean verificarExistenciaCliente(int idCliente) {
        boolean existe = false;
        String sql = "SELECT COUNT(*) FROM clientes WHERE id_cliente = ?";  // Corregido aquí

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    existe = rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error al verificar cliente:\n" + e.getMessage(),
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return existe;

    }//GEN-LAST:event_btn_generarActionPerformed

    private void combo_categoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_categoriaActionPerformed
        productos_categoria();
    }//GEN-LAST:event_combo_categoriaActionPerformed

    private void btn_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_agregarActionPerformed
        agregar();
    }//GEN-LAST:event_btn_agregarActionPerformed

    private void b_imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_imprimirActionPerformed

        int id_usuario = this.idUsuario;
        int id_cliente = this.idCliente;

        // Llamar al método de impresión
        JD_imprimir(id_usuario, id_cliente);
    }//GEN-LAST:event_b_imprimirActionPerformed

    private void btn_MasProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MasProductoActionPerformed
        if (combo_categoria.getItemCount() > 0) {
            combo_categoria.setSelectedIndex(0);
        }

        if (combo_productos.getItemCount() > 0) {
            combo_productos.setSelectedIndex(0);
        }

        t_cantidad.setText("");
    }//GEN-LAST:event_btn_MasProductoActionPerformed

    private void btn_desconexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_desconexionActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(
                null,
                "¿CONFIRMA SALIR DE LA APLICACIÓN?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta == JOptionPane.YES_OPTION) {
            // Obtener la hora de salida
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String horaSalida = sdf.format(new Date());

            // Mostrar mensaje de despedida con hora
            JOptionPane.showMessageDialog(
                    null,
                    "Hora de salida: " + horaSalida + "\n¡Gracias por usar el sistema!",
                    "Desconexión Exitosa",
                    JOptionPane.INFORMATION_MESSAGE
            );

            // Salir de la aplicación
            System.exit(0);
        }
    }//GEN-LAST:event_btn_desconexionActionPerformed

    private void combo_productosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_productosActionPerformed
        // actualizarStockVisual();
        String productoSeleccionado = (String) combo_productos.getSelectedItem();
        if (productoSeleccionado != null && productosStockMap.containsKey(productoSeleccionado)) {
            int stock = productosStockMap.get(productoSeleccionado);
            t_stock.setText(String.valueOf(stock));
        } else {
            t_stock.setText("");
        }
    }//GEN-LAST:event_combo_productosActionPerformed

    //=================== METODOS DE PRODUCTOS =================================
    private void limpiarCampos() {
        t_rut.setText("");
        t_buscarNombre.setText("");
        t_nombre.setText("");
        t_direccion.setText("");
        t_telefono.setText("");
        t_cantidad.setText("");
        t_total.setText("");
        lblBienvenida.setText("");
        lbrut.setText("");

        // Asegúrate de que el botón no se esté limpiando así (esto es incorrecto)
        // btn_MasProducto.setText(""); ← ¡No se debe limpiar el texto del botón!
        // Restablecer combos solo si tienen ítems
        if (combo_categoria.getItemCount() > 0) {
            combo_categoria.setSelectedIndex(0); // Asegúrate que el índice 0 sea "Seleccionar categoría"
        }

        if (combo_productos.getItemCount() > 0) {
            combo_productos.setSelectedIndex(0); // Asegúrate que el índice 0 sea "Seleccionar producto"
        }
    }

    private void actualizarstockVenta(String producto, int cantidadVendida) {
        String sql = "UPDATE productos SET existencia = existencia - ? WHERE nombre = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, cantidadVendida);
            ps.setString(2, producto);

            int filasActualizadas = ps.executeUpdate();

            if (filasActualizadas == 0) {
                JOptionPane.showMessageDialog(null, "No se pudo actualizar el stock. Verifique el producto.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el stock: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setStock() {
        t_stock.setEditable(false);
        t_stock.setFocusable(false);
        t_stock.setBackground(null);
        t_stock.setBorder(null);
        t_stock.setHorizontalAlignment(JTextField.CENTER);
    }

    private void actualizarStockVisual() {
        String productoSeleccionado = (String) combo_productos.getSelectedItem();

        if (productoSeleccionado == null || productoSeleccionado.isEmpty()) {
            t_stock.setText("");
            return;
        }

        String sql = "SELECT existencia FROM productos WHERE nombre = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, productoSeleccionado);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int existencia = rs.getInt("existencia");
                t_stock.setText(String.valueOf(existencia));
            } else {
                t_stock.setText("0");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener stock del producto: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //=================== METODOS DE PRODUCTOS Y CATEGORIAS  ===================
    private void agregar() {
        String productoSeleccionado = (String) combo_productos.getSelectedItem();
        String cantidadTexto = t_cantidad.getText();

        if (productoSeleccionado == null || productoSeleccionado.isEmpty() || cantidadTexto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un producto y especificar la cantidad.");
            return;
        }

        try {
            int cantidad = Integer.parseInt(cantidadTexto);
            int stockActual = Integer.parseInt(t_stock.getText());

            if (cantidad > stockActual) {
                JOptionPane.showMessageDialog(null, "Cantidad solicitada excede el stock disponible.");
                return;
            }

            double precio = obtenerPrecioProducto(productoSeleccionado);
            double subtotal = precio * cantidad;

            totalAcumulado += subtotal;
            t_total.setText(String.format("%.2f", totalAcumulado));

            // Descontar el stock en la base de datos
            actualizarstockVenta(productoSeleccionado, cantidad);

            // Actualizar el campo visual del stock en la interfaz
            t_stock.setText(String.valueOf(stockActual - cantidad));

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cantidad inválida. Ingrese un número entero.");
        }
    }

    private double obtenerPrecioProducto(String nombreProducto) {
        double precio = 0.0;
        String sql = "SELECT precio FROM productos WHERE nombre = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombreProducto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                precio = rs.getDouble("precio");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener precio del producto: " + e.getMessage());
        }

        return precio;
    }

    private void productos_categoria() {
        String categoriaSeleccionada = (String) combo_categoria.getSelectedItem();

        combo_productos.removeAllItems();
        productosStockMap.clear();
        t_stock.setText("");

        if (categoriaSeleccionada == null || categoriaSeleccionada.equals("Seleccione una categoria")) {
            return;
        }

        Integer idCategoria = categoriasMap.get(categoriaSeleccionada);
        if (idCategoria == null) {
            return;
        }

        String sql = "SELECT nombre, existencia FROM productos WHERE id_categoria = ?";

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCategoria);
            ResultSet rs = ps.executeQuery();

            DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
            boolean productosEncontrados = false;

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                int stock = rs.getInt("existencia");

                productosStockMap.put(nombre, stock);
                modelo.addElement(nombre);
                productosEncontrados = true;
            }

            combo_productos.setModel(modelo);

            if (!productosEncontrados) {
                combo_productos.addItem("Sin productos disponibles");
                t_stock.setText("");
            } else {
                // Mostrar el stock del primer producto automáticamente
                String primerProducto = (String) combo_productos.getItemAt(0);
                if (primerProducto != null && productosStockMap.containsKey(primerProducto)) {
                    int stock = productosStockMap.get(primerProducto);
                    t_stock.setText(String.valueOf(stock));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar productos: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarCategorias() {
        combo_categoria.removeAllItems();
        categoriasMap.clear();
        categoriasConStock.clear(); // limpiar también este mapa

        combo_categoria.addItem("Seleccione una categoria");

        String sql = """
        SELECT c.id_categoria, c.nombre_categoria,
               EXISTS (
                   SELECT 1 FROM productos p
                   WHERE p.id_categoria = c.id_categoria AND p.existencia > 0
               ) AS tiene_stock
        FROM categorias c
    """;

        try (Connection con = Conexiones.conectar(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_categoria");
                String nombre = rs.getString("nombre_categoria");
                boolean tieneStock = rs.getBoolean("tiene_stock");

                combo_categoria.addItem(nombre);
                categoriasMap.put(nombre, id);
                categoriasConStock.put(nombre, tieneStock); // guardar si tiene stock
            }

            // Renderizado sencillo para mostrar en gris las categorías sin stock
            combo_categoria.setRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                        boolean isSelected, boolean cellHasFocus) {
                    JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                    if (value != null && categoriasConStock.containsKey(value.toString())) {
                        if (!categoriasConStock.get(value.toString())) {
                            label.setForeground(Color.GRAY); // solo cambia el color si no tiene stock
                        } else {
                            label.setForeground(Color.BLACK); // normal si tiene stock
                        }
                    }
                    return label;
                }
            });

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar categorías: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //=================== METODOS DE RESULTADOS ================================
    // no tocar 
    private void generarBoleta() {
        String[] datosUsuario = obtenerDatosUsuario(idUsuario);
        String nombre_usuario = datosUsuario[0];
        String departamento = datosUsuario[1];
        String nombre_cliente = obtenerNombreCliente(idCliente);

        BigDecimal valor_venta = new BigDecimal(t_total.getText().trim());
        String hora_fin = new SimpleDateFormat("HH:mm:ss").format(new Date());
        java.sql.Date fecha = new java.sql.Date(System.currentTimeMillis());

        if (ventanaReportes == null) {
            ventanaReportes = new VentanaReportesVenta();
        }

        ventanaReportes.insertarReporteVenta(
                idUsuario,
                nombre_usuario,
                departamento,
                idCliente,
                nombre_cliente,
                valor_venta,
                horaInicio,
                hora_fin,
                fecha
        );

        actualizarStockVisual();
        JD_imprimir(idUsuario, idCliente);

        limpiarCampos();
        ventanaReportes.mostrarReporteCaja();
        ventanaReportes.setVisible(true);
    }

    private Map<String, Object> obtenerDetalleVenta(int idUsuario, int idCliente) {
        Map<String, Object> datos = new HashMap<>();

        try {
            // === Usuario ===
            String sqlUsuario = "SELECT nombre, departamento FROM usuarios WHERE id_usuario = ?";
            try (PreparedStatement pst = Conexiones.conectar().prepareStatement(sqlUsuario)) {
                pst.setInt(1, idUsuario);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    datos.put("usuario_nombre", rs.getString("nombre"));
                    datos.put("usuario_departamento", rs.getString("departamento"));
                }
            }

            // === Cliente ===
            String sqlCliente = "SELECT nombre, rut FROM clientes WHERE id_cliente = ?";
            try (PreparedStatement pst = Conexiones.conectar().prepareStatement(sqlCliente)) {
                pst.setInt(1, idCliente);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    datos.put("cliente_nombre", rs.getString("nombre"));
                    datos.put("cliente_rut", rs.getString("rut"));
                }
            }

            // === Fecha ===
            String fechaVenta = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
            datos.put("fecha_venta", fechaVenta);

            // === Detalle de productos vendidos ===
            String sqlDetalles = "SELECT dv.cantidad, (dv.cantidad * dv.precio_unitario) AS subtotal, v.total_venta "
                    + "FROM detalle_venta dv "
                    + "JOIN ventas v ON dv.id_venta = v.id_venta "
                    + "WHERE v.id_cliente = ? ";

            List<Map<String, String>> listaDetalles = new ArrayList<>();
            double total = 0;
            int cantidadTotal = 0;

            try (PreparedStatement pst = Conexiones.conectar().prepareStatement(sqlDetalles)) {
                pst.setInt(1, idCliente);
                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    int cantidad = rs.getInt("cantidad");
                    double subtotal = rs.getDouble("subtotal");

                    Map<String, String> fila = new HashMap<>();
                    fila.put("cantidad", String.valueOf(cantidad));
                    fila.put("subtotal", String.format("%.0f", subtotal));

                    listaDetalles.add(fila);
                    cantidadTotal += cantidad;
                    total += subtotal;
                }
            }

            datos.put("detalles", listaDetalles);
            datos.put("cantidad_total", cantidadTotal);
            datos.put("total", total);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return datos;
    }

    // Método privado que genera el PDF y abre la boleta
    private void Imprimir(int id_usuario, int id_cliente) {
        try {
            Map<String, Object> detallesVenta = obtenerDetalleVenta(id_usuario, id_cliente);

            if (detallesVenta.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se encontraron detalles para esta venta.",
                        "Sin detalles", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            @SuppressWarnings("unchecked")
            List<Map<String, String>> listaDetalles = (List<Map<String, String>>) detallesVenta.get("detalles");
            double totalGastado = (double) detallesVenta.get("total");
            int cantidadTotal = (int) detallesVenta.get("cantidad_total");

            Document documento = new Document(PageSize.LETTER);
            String rutaArchivo = "D:/UST 2/Integracion de Competencias I/Orion/AlmacenPro +/almacenPro+/boletas caja" + id_cliente + "_"
                    + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".pdf";
            new File("boletas").mkdirs();
            PdfWriter.getInstance(documento, new FileOutputStream(rutaArchivo));
            documento.open();

            Font fuenteNormal = new Font(Font.FontFamily.HELVETICA, 10);
            Font fuenteNegrita = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

            documento.add(new Paragraph("Almacen Pro+ S.A.", fuenteNegrita));
            documento.add(new Paragraph("Dirección: Calle Falsa, 123", fuenteNormal));
            documento.add(new Paragraph("Teléfono: 123 456 7890", fuenteNormal));
            documento.add(new Paragraph("\n"));
            documento.add(new Paragraph("BOLETA DE VENTA", new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD)));
            documento.add(new Paragraph("\n"));

            // Agregar detalles del usuario y cliente
            documento.add(new Paragraph("Vendedor: " + detallesVenta.get("usuario_nombre"), fuenteNormal));
            documento.add(new Paragraph("Departamento: " + detallesVenta.get("usuario_departamento"), fuenteNormal));
            documento.add(new Paragraph("Cliente: " + detallesVenta.get("cliente_nombre"), fuenteNormal));
            documento.add(new Paragraph("RUT: " + detallesVenta.get("cliente_rut"), fuenteNormal));
            documento.add(new Paragraph("Fecha: " + detallesVenta.get("fecha_venta"), fuenteNormal));
            documento.add(new Paragraph("\n"));

            // Tabla con detalles de la venta
            PdfPTable tablaPDF = new PdfPTable(2); // Dos columnas: cantidad y subtotal
            tablaPDF.setWidthPercentage(100);
            tablaPDF.setWidths(new float[]{2f, 1f});
            tablaPDF.addCell(new PdfPCell(new Phrase("Cantidad", fuenteNegrita)));
            tablaPDF.addCell(new PdfPCell(new Phrase("Subtotal", fuenteNegrita)));

            for (Map<String, String> detalle : listaDetalles) {
                tablaPDF.addCell(new Phrase(detalle.get("cantidad"), fuenteNormal));
                tablaPDF.addCell(new Phrase("$" + detalle.get("subtotal"), fuenteNormal));
            }

            documento.add(tablaPDF);
            documento.add(new Paragraph("\n"));

            // Agregar totales al final
            Paragraph cantidadTotalP = new Paragraph("Cantidad total de productos: " + cantidadTotal, fuenteNegrita);
            cantidadTotalP.setAlignment(Element.ALIGN_RIGHT);
            documento.add(cantidadTotalP);

            Paragraph total = new Paragraph("Total: $" + String.format("%,.0f", totalGastado), fuenteNegrita);
            total.setAlignment(Element.ALIGN_RIGHT);
            documento.add(total);

            documento.close();
            Desktop.getDesktop().open(new File(rutaArchivo));

            JOptionPane.showMessageDialog(null, "Boleta generada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al generar la boleta: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public void JD_imprimir(int id_usuario, int id_cliente) {
        JDialog jdImprimir = new JDialog();
        jdImprimir.setUndecorated(true);
        jdImprimir.setSize(300, 180);
        jdImprimir.setLocationRelativeTo(null);
        jdImprimir.setLayout(new FlowLayout());

        JButton botonImprimir = new JButton("Imprimir Boleta");
        botonImprimir.addActionListener(e -> {
            Imprimir(id_usuario, id_cliente);
            jdImprimir.dispose();
        });

        jdImprimir.add(botonImprimir);
        jdImprimir.setVisible(true);

    }

    //=================== METODOS DE AUXILIARES ================================
    public void TexfieldDesactivados() {
        t_nombre.setEditable(false);
        t_direccion.setEditable(false);
        t_telefono.setEditable(false);

        Color grisClaro = new Color(230, 230, 230); // Gris suave
        t_nombre.setBackground(grisClaro);
        t_direccion.setBackground(grisClaro);
        t_telefono.setBackground(grisClaro);
    }

    private void configurarVentana() {
        // Configuración básica de la ventana
        setTitle("Ventana de Caja");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setResizable(false);

        // Configurar campos y etiquetas iniciales
        lb_idUsuario.setText("ID Usuario: " + idUsuario);
        t_total.setText("0.00");

        // Configurar la fecha actual
        j_date.setDate(new Date());

        // Configurar la tabla de productos si existe
        if (tabla_productos != null) {
            tabla_productos.setDefaultEditor(Object.class, null); // Hacer la tabla no editable
            tabla_productos.getTableHeader().setReorderingAllowed(false); // Evitar reordenamiento de columnas
        }

//        // Configurar botones
        b_buscar.setFocusPainted(true);
//        btn_generar.setFocusPainted(false);
//        btn_generar.setEnabled(false); // Deshabilitar hasta que haya productos

        // Agregar listeners
        t_total.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != '.' && c != KeyEvent.VK_BACK_SPACE) {
                    e.consume();
                }
            }
        });

        // Configurar el estado inicial de los campos de cliente
        t_rut.setEditable(true);
        t_nombre.setEditable(false);
        t_direccion.setEditable(false);
        t_telefono.setEditable(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDialog JD_IMPRIMIR;
    private javax.swing.JLabel Total;
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_imprimir;
    private javax.swing.JRadioButton btn_MasProducto;
    private javax.swing.JButton btn_agregar;
    private javax.swing.JButton btn_desconexion;
    private javax.swing.JButton btn_generar;
    private javax.swing.JButton btn_limpiar;
    private javax.swing.JComboBox<String> combo_categoria;
    private javax.swing.JComboBox<String> combo_productos;
    private com.toedter.calendar.JDateChooser j_date;
    private javax.swing.JLabel l_cantidad;
    private javax.swing.JLabel l_categoria;
    private javax.swing.JLabel l_direccion;
    private javax.swing.JLabel l_fecha_ingreso;
    private javax.swing.JLabel l_nombre;
    private javax.swing.JLabel l_nombrebuscar;
    private javax.swing.JLabel l_productos;
    private javax.swing.JLabel l_rut;
    private javax.swing.JLabel l_stock;
    private javax.swing.JLabel l_telefono;
    private javax.swing.JLabel lb_idUsuario;
    private javax.swing.JLabel lblBienvenida;
    private javax.swing.JLabel lbrut;
    private java.awt.Scrollbar scrollbar1;
    private javax.swing.JTextField t_buscarNombre;
    private javax.swing.JTextField t_cantidad;
    private javax.swing.JTextField t_direccion;
    private javax.swing.JTextField t_nombre;
    private javax.swing.JTextField t_rut;
    private javax.swing.JTextField t_stock;
    private javax.swing.JTextField t_telefono;
    private javax.swing.JTextField t_total;
    // End of variables declaration//GEN-END:variables
}
