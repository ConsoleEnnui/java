package ventanas;
import conexiones.Conexiones;

import java.awt.Component;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Date;

import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

import java.time.LocalDate;

public class VentanaAdminProductos extends javax.swing.JFrame {

    public VentanaAdminProductos() {
        initComponents();
        setLocationRelativeTo(null); // ventana abre en el centro
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);
        recargarCategoriasDesdeBD();
        render();
        combo_categoria.setSelectedItem("seleccione una categoria");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_titulo_ventana = new javax.swing.JLabel();
        l_Precio = new javax.swing.JLabel();
        l_descripcion = new javax.swing.JLabel();
        l_nombreProducto = new javax.swing.JLabel();
        t_nombre = new javax.swing.JTextField();
        t_descripcion = new javax.swing.JTextField();
        t_precio = new javax.swing.JTextField();
        btn_insertar = new javax.swing.JButton();
        btn_actualizar = new javax.swing.JButton();
        btn_borrar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        l_idcProducto = new javax.swing.JLabel();
        t_idProducto = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        l_existencia = new javax.swing.JLabel();
        t_existencia = new javax.swing.JTextField();
        l_categoria = new javax.swing.JLabel();
        l_fecha_ingreso = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        btn_limpiar = new javax.swing.JButton();
        combo_categoria = new javax.swing.JComboBox<>();
        b_nuevaCategoria = new javax.swing.JButton();
        j_date = new com.toedter.calendar.JDateChooser();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Administrar Productos");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_titulo_ventana.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_titulo_ventana.setForeground(new java.awt.Color(0, 102, 102));
        l_titulo_ventana.setText("Administrar productos");
        getContentPane().add(l_titulo_ventana, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 40, -1, -1));

        l_Precio.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_Precio.setForeground(new java.awt.Color(0, 102, 102));
        l_Precio.setText("Precio");
        getContentPane().add(l_Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, -1, -1));

        l_descripcion.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_descripcion.setForeground(new java.awt.Color(0, 102, 102));
        l_descripcion.setText("Descripcion");
        getContentPane().add(l_descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, -1, -1));

        l_nombreProducto.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_nombreProducto.setForeground(new java.awt.Color(0, 102, 102));
        l_nombreProducto.setText("Nombre");
        getContentPane().add(l_nombreProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, -1));

        t_nombre.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_nombre.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, 170, -1));

        t_descripcion.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_descripcion.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 210, 490, -1));

        t_precio.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_precio.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 130, -1));

        btn_insertar.setBackground(new java.awt.Color(51, 153, 0));
        btn_insertar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btn_insertar.setForeground(new java.awt.Color(255, 255, 255));
        btn_insertar.setText("Insertar");
        btn_insertar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_insertarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 470, 130, 50));

        btn_actualizar.setBackground(new java.awt.Color(51, 153, 0));
        btn_actualizar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btn_actualizar.setForeground(new java.awt.Color(255, 255, 255));
        btn_actualizar.setText("Actualizar");
        btn_actualizar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 470, 130, 50));

        btn_borrar.setBackground(new java.awt.Color(51, 153, 0));
        btn_borrar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btn_borrar.setForeground(new java.awt.Color(255, 255, 255));
        btn_borrar.setText("Borrar");
        btn_borrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_borrarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 470, 130, 50));

        btn_cancelar.setBackground(new java.awt.Color(51, 153, 0));
        btn_cancelar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btn_cancelar.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancelar.setText("Cancelar");
        btn_cancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 470, 130, 50));

        l_idcProducto.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_idcProducto.setForeground(new java.awt.Color(0, 102, 102));
        l_idcProducto.setText("ID");
        getContentPane().add(l_idcProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, -1, -1));

        t_idProducto.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_idProducto.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_idProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 60, -1));

        btn_buscar.setBackground(new java.awt.Color(51, 153, 0));
        btn_buscar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setText("Buscar");
        btn_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 80, 30));

        l_existencia.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_existencia.setForeground(new java.awt.Color(0, 102, 102));
        l_existencia.setText("Existencia");
        getContentPane().add(l_existencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, 30));

        t_existencia.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_existencia.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_existencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 60, -1));

        l_categoria.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_categoria.setForeground(new java.awt.Color(0, 102, 102));
        l_categoria.setText("Categoria");
        getContentPane().add(l_categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, -1, 30));

        l_fecha_ingreso.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_fecha_ingreso.setForeground(new java.awt.Color(0, 102, 102));
        l_fecha_ingreso.setText("Fecha Ingreso");
        getContentPane().add(l_fecha_ingreso, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 390, -1, 30));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 550, 200, 50));

        btn_limpiar.setBackground(new java.awt.Color(51, 153, 0));
        btn_limpiar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        btn_limpiar.setText("Limpiar");
        btn_limpiar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_limpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 410, 70, -1));

        combo_categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una categoria", "Abarrotes", "Higiene", "Lácteos y Proteínas", "Alimentos secos", "Bebidas", "Dulces", "Panaderia", " " }));
        getContentPane().add(combo_categoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 180, -1));

        b_nuevaCategoria.setText("Nueva");
        b_nuevaCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_nuevaCategoriaActionPerformed(evt);
            }
        });
        getContentPane().add(b_nuevaCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 350, -1, -1));
        getContentPane().add(j_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 130, 30));

        l_fondo.setForeground(new java.awt.Color(0, 102, 102));
        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_productos.jpg"))); // NOI18N
        l_fondo.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //=================== METODOS ACTION LISTENER ==============================
    private void btn_insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_insertarActionPerformed
        insertarProducto();
    }//GEN-LAST:event_btn_insertarActionPerformed

    private void btn_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_borrarActionPerformed
        // Obtener y validar el valor de id_producto
        String idProducto = t_idProducto.getText().trim();
        if (idProducto.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR UN ID DE PRODUCTO VÁLIDO",
                    "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idProductoInt;
        try {
            idProductoInt = Integer.parseInt(idProducto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "EL ID DEL PRODUCTO DEBE SER UN VALOR NUMÉRICO",
                    "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Confirmación del usuario
        int confirmacion = JOptionPane.showConfirmDialog(null,
                "¿ESTÁ SEGURO QUE DESEA BORRAR ESTE PRODUCTO?",
                "CONFIRMAR", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            String query = "DELETE FROM productos WHERE id_producto = ?";
            try (Connection conn = new Conexiones().conectar(); PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setInt(1, idProductoInt);
                int filasAfectadas = stmt.executeUpdate();

                if (filasAfectadas > 0) {
                    JOptionPane.showMessageDialog(null, "PRODUCTO BORRADO CORRECTAMENTE", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
                    limpiarCampos();
                } else {
                    JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ PRODUCTO CON ESE ID", "RESULTADO", JOptionPane.WARNING_MESSAGE);
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "ERROR BORRANDO PRODUCTO: " + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "BORRADO DE PRODUCTO CANCELADO", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_btn_borrarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        buscaridProducto();
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        if (t_idProducto.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR UN ID DE PRODUCTO VALIDO", "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idProducto = t_idProducto.getText().trim();
        String nombre = t_nombre.getText().trim();
        String descripcion = t_descripcion.getText().trim();
        String precioStr = t_precio.getText().trim();
        String existenciaStr = t_existencia.getText().trim();
        String nombreCategoria = (String) combo_categoria.getSelectedItem();

        java.util.Date fechaUtil = j_date.getDate();

        if (fechaUtil == null) {
            JOptionPane.showMessageDialog(null, "DEBE SELECCIONAR UNA FECHA DE INGRESO", "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        java.sql.Date fechaSQL = new java.sql.Date(fechaUtil.getTime());
        LocalDate fechaIngreso = fechaSQL.toLocalDate();

        if (fechaIngreso.isAfter(LocalDate.now())) {
            JOptionPane.showMessageDialog(null, "LA FECHA INGRESADA NO DEBE SER SUPERIOR A LA FECHA ACTUAL", "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double precio;
        int existencia;
        try {
            precio = Double.parseDouble(precioStr);
            existencia = Integer.parseInt(existenciaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "DEBE COLOCAR PRECIO Y EXISTENCIA CON VALORES NUMERICOS", "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Buscar id_categoria según el nombre
        int idCategoria;
        String consultaCategoria = "SELECT id_categoria FROM categorias WHERE nombre_categoria = ?";
        try (Connection conn = new Conexiones().conectar(); PreparedStatement stmtCategoria = conn.prepareStatement(consultaCategoria)) {
            stmtCategoria.setString(1, nombreCategoria);
            ResultSet rsCategoria = stmtCategoria.executeQuery();
            if (rsCategoria.next()) {
                idCategoria = rsCategoria.getInt("id_categoria");
            } else {
                JOptionPane.showMessageDialog(null, "LA CATEGORÍA SELECCIONADA NO EXISTE", "ALERTA", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR AL VERIFICAR CATEGORIA: " + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, existencia = ?, id_categoria = ?, fecha_ingreso = ? WHERE id_producto = ?";
        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar();

        try {
            con.setAutoCommit(false);
            PreparedStatement consulta = con.prepareStatement(sql);
            consulta.setString(1, nombre);
            consulta.setString(2, descripcion);
            consulta.setDouble(3, precio);
            consulta.setInt(4, existencia);
            consulta.setInt(5, idCategoria);
            consulta.setDate(6, fechaSQL); 
            consulta.setInt(7, Integer.parseInt(idProducto));

            int filasActualizadas = consulta.executeUpdate();

            if (filasActualizadas > 0) {
                con.commit();
                JOptionPane.showMessageDialog(null, "PRODUCTO ACTUALIZADO CORRECTAMENTE.", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
                t_idProducto.setText("");
                t_nombre.setText("");
                t_descripcion.setText("");
                t_precio.setText("");
                t_existencia.setText("");
                combo_categoria.setSelectedIndex(0);
                j_date.setDate(null); // ✅ Limpia el JDateChooser
            } else {
                con.rollback();
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRO PRODUCTO", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null, "ERROR ACTUALIZANDO PRODUCTOS: " + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        new VentanaProductos().setVisible(true); 
        dispose(); 
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btn_limpiarActionPerformed

    private void b_nuevaCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_nuevaCategoriaActionPerformed
        nuevaCategoria();

    }//GEN-LAST:event_b_nuevaCategoriaActionPerformed
    
    //=================== METODOS DE PRODUCTOS =================================
    private void buscaridProducto() {
        String idProducto = t_idProducto.getText().trim();

        try {
            int idProductoInt = Integer.parseInt(idProducto);
            Conexiones conexion = new Conexiones();
            String sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.existencia, p.fecha_ingreso, c.nombre_categoria "
                    + "FROM productos p JOIN categorias c ON p.id_categoria = c.id_categoria WHERE p.id_producto = ?";

            try (Connection con = conexion.conectar(); PreparedStatement consulta = con.prepareStatement(sql)) {
                consulta.setInt(1, idProductoInt);
                ResultSet resultado = consulta.executeQuery();

                if (resultado.next()) {
                    t_idProducto.setText(String.valueOf(resultado.getInt("id_producto")));
                    t_nombre.setText(resultado.getString("nombre"));
                    t_descripcion.setText(resultado.getString("descripcion"));
                    t_precio.setText(String.valueOf(resultado.getDouble("precio")));
                    t_existencia.setText(String.valueOf(resultado.getInt("existencia")));

                    // ← ← ← Aquí establecemos la fecha en el JDateChooser
                    Date fechaBD = resultado.getDate("fecha_ingreso");
                    j_date.setDate(fechaBD);

                    // Actualizar la categoría en el combo
                    String categoriaBD = resultado.getString("nombre_categoria").trim();
                    for (int i = 0; i < combo_categoria.getItemCount(); i++) {
                        String itemCombo = combo_categoria.getItemAt(i).toString().trim();
                        if (itemCombo.equalsIgnoreCase(categoriaBD)) {
                            combo_categoria.setSelectedIndex(i);
                            break;
                        }
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "PRODUCTO NO ENCONTRADO", "RESULTADO", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR ID DE PRODUCTO CORRECTO", "ALERTA", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void nuevaCategoria() {
        String nuevaCat = JOptionPane.showInputDialog(
                this,
                "Ingrese nueva categoría:",
                "Nueva Categoría",
                JOptionPane.PLAIN_MESSAGE
        );

        // 1) Si el usuario pulsó Cancelar, nuevaCat es null: salimos sin mensaje
        if (nuevaCat == null) {
            return;
        }

        // 2) Si ingresó solo espacios o nada, mostramos aviso
        if (nuevaCat.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Debe ingresar un nombre de categoría válido.",
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // 3) Si aquí, el texto es válido: hacemos el INSERT
        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO categorias (nombre_categoria) VALUES (?)"
        )) {

            ps.setString(1, nuevaCat.trim());
            int filas = ps.executeUpdate();

            if (filas > 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Categoría \"" + nuevaCat + "\" agregada con éxito.",
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE
                );
                recargarCategoriasDesdeBD();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al agregar la categoría:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void recargarCategoriasDesdeBD() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = Conexiones.conectar();
            String sql = "SELECT nombre_categoria FROM categorias ORDER BY nombre_categoria";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
            while (rs.next()) {
                modelo.addElement(rs.getString("nombre_categoria"));
            }
            combo_categoria.setModel(modelo);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error al cargar categorías:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "ERROR AL CERRAR CONEXION"); }
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "ERROR AL PREPARAR LA CONSULTA "); }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                /* ignorable */ }
        }

    }

    private void insertarProducto() {
        String nombre = t_nombre.getText().trim();
        String descripcion = t_descripcion.getText().trim();
        String precioStr = t_precio.getText().trim();
        String existenciaStr = t_existencia.getText().trim();

        java.util.Date fechaDate = j_date.getDate();
        if (fechaDate == null) {
            JOptionPane.showMessageDialog(this,
                    "Debe seleccionar una fecha de ingreso.",
                    "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Convertir java.util.Date a java.sql.Date
        java.sql.Date sqlFechaIngreso = new java.sql.Date(fechaDate.getTime());

        if (sqlFechaIngreso.toLocalDate().isAfter(LocalDate.now())) {
            JOptionPane.showMessageDialog(this,
                    "La fecha de ingreso no debe ser posterior a la fecha actual.",
                    "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validar que t_idProducto esté vacío
        if (!t_idProducto.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "NO ES NECESARIO COLOCAR ID DE PRODUCTO\nDEJE ESTE CAMPO VACIO",
                    "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Obtener el id de la categoría desde el nombre
        String nombreCat = (String) combo_categoria.getSelectedItem();
        if (nombreCat == null || nombreCat.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Debe seleccionar una categoría.",
                    "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idCategoria;
        String sqlId = "SELECT id_categoria FROM categorias WHERE nombre_categoria = ?";
        try (
                Connection conn = Conexiones.conectar(); PreparedStatement psId = conn.prepareStatement(sqlId)) {
            psId.setString(1, nombreCat);
            try (ResultSet rs = psId.executeQuery()) {
                if (rs.next()) {
                    idCategoria = rs.getInt("id_categoria");
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Categoría no encontrada en la base de datos.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error al buscar categoría:\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validar y convertir precio y existencia
        double precio;
        int existencia;
        try {
            precio = Double.parseDouble(precioStr);
            existencia = Integer.parseInt(existenciaStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                    "DEBE COLOCAR PRECIO, EXISTENCIA\nCON VALORES NUMERICOS",
                    "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Insertar en la base de datos
        String sql = "INSERT INTO productos (nombre, descripcion, precio, existencia, id_categoria, fecha_ingreso) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (
                Connection con = Conexiones.conectar(); PreparedStatement consulta = con.prepareStatement(sql)) {
            consulta.setString(1, nombre);
            consulta.setString(2, descripcion);
            consulta.setDouble(3, precio);
            consulta.setInt(4, existencia);
            consulta.setInt(5, idCategoria);
            consulta.setDate(6, sqlFechaIngreso);

            int filasInsertadas = consulta.executeUpdate();
            if (filasInsertadas > 0) {
                JOptionPane.showMessageDialog(null,
                        "PRODUCTO INSERTADO CORRECTAMENTE",
                        "RESULTADO",
                        JOptionPane.INFORMATION_MESSAGE);
                // Limpiar campos
                t_idProducto.setText("");
                t_nombre.setText("");
                t_descripcion.setText("");
                t_precio.setText("");
                t_existencia.setText("");
                combo_categoria.setSelectedIndex(-1);
                j_date.setDate(null); // limpiar JDateChooser
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "ERROR INSERTANDO PRODUCTO:\n" + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void render() {
        combo_categoria.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                if (value == null) {
                    value = "Seleccionar una categoría";
                }
                return super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            }
        });

    }
    
    //=================== METODOS AUXILIARES ===================================
    
    private void limpiarCampos() {
        t_idProducto.setText("");
        t_nombre.setText("");
        t_descripcion.setText("");
        t_precio.setText("");
        t_existencia.setText("");
        j_date.setDate(null);

        combo_categoria.setSelectedItem(null);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAdminProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAdminProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAdminProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAdminProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAdminProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_nuevaCategoria;
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_borrar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_insertar;
    private javax.swing.JButton btn_limpiar;
    private javax.swing.JComboBox<String> combo_categoria;
    private com.toedter.calendar.JDateChooser j_date;
    private javax.swing.JLabel l_Precio;
    private javax.swing.JLabel l_categoria;
    private javax.swing.JLabel l_descripcion;
    private javax.swing.JLabel l_existencia;
    private javax.swing.JLabel l_fecha_ingreso;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idcProducto;
    private javax.swing.JLabel l_nombreProducto;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel l_titulo_ventana;
    private javax.swing.JTextField t_descripcion;
    private javax.swing.JTextField t_existencia;
    private javax.swing.JTextField t_idProducto;
    private javax.swing.JTextField t_nombre;
    private javax.swing.JTextField t_precio;
    // End of variables declaration//GEN-END:variables
}
