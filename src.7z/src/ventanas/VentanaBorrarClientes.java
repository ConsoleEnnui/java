package ventanas;
import conexiones.Conexiones;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class VentanaBorrarClientes extends javax.swing.JFrame {

    public VentanaBorrarClientes() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_titulo_ventana = new javax.swing.JLabel();
        l_nombre = new javax.swing.JLabel();
        l_direccion = new javax.swing.JLabel();
        l_telefono = new javax.swing.JLabel();
        btn_borrar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        l_idcCliente = new javax.swing.JLabel();
        t_idCliente = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        t_nombreCliente = new javax.swing.JLabel();
        t_direccionCliente = new javax.swing.JLabel();
        t_telefonoCliente = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Borrar clientes");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_titulo_ventana.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_titulo_ventana.setForeground(new java.awt.Color(0, 102, 102));
        l_titulo_ventana.setText("Borrar cliente");
        getContentPane().add(l_titulo_ventana, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, -1, -1));

        l_nombre.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_nombre.setForeground(new java.awt.Color(0, 102, 102));
        l_nombre.setText("Nombre");
        getContentPane().add(l_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        l_direccion.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_direccion.setForeground(new java.awt.Color(0, 102, 102));
        l_direccion.setText("Direccion");
        getContentPane().add(l_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, -1, -1));

        l_telefono.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_telefono.setForeground(new java.awt.Color(0, 102, 102));
        l_telefono.setText("Telefono");
        getContentPane().add(l_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, -1, -1));

        btn_borrar.setBackground(new java.awt.Color(51, 153, 0));
        btn_borrar.setForeground(new java.awt.Color(255, 255, 255));
        btn_borrar.setText("Borrar");
        btn_borrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_borrarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 130, 50));

        btn_cancelar.setBackground(new java.awt.Color(51, 153, 0));
        btn_cancelar.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancelar.setText("Cancelar");
        btn_cancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 130, 50));

        l_idcCliente.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_idcCliente.setForeground(new java.awt.Color(0, 102, 102));
        l_idcCliente.setText("id Cliente");
        getContentPane().add(l_idcCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, -1, 30));

        t_idCliente.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_idCliente.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 60, -1));

        btn_buscar.setBackground(new java.awt.Color(51, 153, 0));
        btn_buscar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setText("Buscar");
        btn_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 70, 30));

        t_nombreCliente.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        t_nombreCliente.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(t_nombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 300, -1));

        t_direccionCliente.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        t_direccionCliente.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(t_direccionCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 300, -1));

        t_telefonoCliente.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        t_telefonoCliente.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(t_telefonoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 300, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 350, 130, 30));

        l_fondo.setForeground(new java.awt.Color(0, 102, 102));
        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_insertClientes.jpg"))); // NOI18N
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //=================== METODOS ACTIO LISTENER ===============================
    private void btn_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_borrarActionPerformed
        String idcliente = t_idCliente.getText().trim(); // borramos por Id Cliente 

        try {
            Integer.parseInt(idcliente);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "DEBE BUSCAR UN CLIENTE A BORRAR", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            t_idCliente.setText(""); // si no ingresa valor entero, se borra
            return;
        }

        // Consulta SQL corregida
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";

        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar();

        try {
            PreparedStatement ejecucion = con.prepareStatement(sql);
            ejecucion.setInt(1, Integer.parseInt(idcliente));

            int fila = ejecucion.executeUpdate(); // ejecutamos el borrado

            if (fila > 0) {
                JOptionPane.showMessageDialog(null, "CLIENTE BORRADO CON ÉXITO", "AVISO",
                        JOptionPane.INFORMATION_MESSAGE);
                // Limpiar campos
                t_nombreCliente.setText("");
                t_direccionCliente.setText("");
                t_telefonoCliente.setText("");
                t_idCliente.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "CLIENTE NO EXISTE", "AVISO",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR CONECTANDO A LA BASE DE DATOS", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_btn_borrarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        dispose();
        new VentanaClientes().setVisible(true);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String idCliente = t_idCliente.getText();
        try {
            Integer.parseInt(idCliente);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "DEBE COLOCAR UN VALOR ENTERO", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);

            t_idCliente.setText(""); // si no ingresa valor entero seteamos la casilla en blanco para voler a ingresar.
            return;
        }

        String sql = "select nombre, direccion, telefono from clientes where id_cliente = ?";

        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar(); // interfaz Conection = invocando al mmetodo de mi clase conexiones .

        try {
            PreparedStatement consulta = con.prepareStatement(sql); // consulta a la base de datos.
            consulta.setString(1, idCliente);
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) { // si la consulta encuentra resultado : 
                t_nombreCliente.setText(resultado.getString("nombre"));
                t_direccionCliente.setText(resultado.getString("direccion"));
                t_telefonoCliente.setText(resultado.getString("telefono"));

            } else {
                JOptionPane.showMessageDialog(null, " CLIENTE NO ENCONTRADO", "ALERTA",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR CONECTANDO A LA BASE DE DATOS", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btn_buscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBorrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBorrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBorrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBorrarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBorrarClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_borrar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel l_direccion;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idcCliente;
    private javax.swing.JLabel l_nombre;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel l_telefono;
    private javax.swing.JLabel l_titulo_ventana;
    private javax.swing.JLabel t_direccionCliente;
    private javax.swing.JTextField t_idCliente;
    private javax.swing.JLabel t_nombreCliente;
    private javax.swing.JLabel t_telefonoCliente;
    // End of variables declaration//GEN-END:variables
}
