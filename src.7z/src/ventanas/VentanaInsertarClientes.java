package ventanas;

import conexiones.Conexiones;
import ventanas.VentanaClientes;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class VentanaInsertarClientes extends javax.swing.JFrame {

    private VentanaClientes ventanaClientes;

    public VentanaInsertarClientes() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);
        this.ventanaClientes = ventanaClientes;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_titulo_ventana = new javax.swing.JLabel();
        l_nombre = new javax.swing.JLabel();
        l_direccion = new javax.swing.JLabel();
        l_telefono = new javax.swing.JLabel();
        t_nombre = new javax.swing.JTextField();
        t_direccion = new javax.swing.JTextField();
        t_telefono = new javax.swing.JTextField();
        btn_insertar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        l_pieVentana = new javax.swing.JLabel();
        l_rut = new javax.swing.JLabel();
        t_rut = new javax.swing.JTextField();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Insertar clientes");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_titulo_ventana.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_titulo_ventana.setForeground(new java.awt.Color(0, 102, 102));
        l_titulo_ventana.setText("Insertar cliente");
        getContentPane().add(l_titulo_ventana, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, -1, -1));

        l_nombre.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_nombre.setForeground(new java.awt.Color(0, 102, 102));
        l_nombre.setText("Telefono");
        getContentPane().add(l_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));

        l_direccion.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_direccion.setForeground(new java.awt.Color(0, 102, 102));
        l_direccion.setText("Direccion");
        getContentPane().add(l_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, -1));

        l_telefono.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_telefono.setForeground(new java.awt.Color(0, 102, 102));
        l_telefono.setText("Nombre");
        getContentPane().add(l_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, -1, -1));

        t_nombre.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_nombre.setForeground(new java.awt.Color(51, 21, 221));
        getContentPane().add(t_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 170, -1));

        t_direccion.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_direccion.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 370, -1));

        t_telefono.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_telefono.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 170, -1));

        btn_insertar.setBackground(new java.awt.Color(51, 153, 0));
        btn_insertar.setForeground(new java.awt.Color(255, 255, 255));
        btn_insertar.setText("Insertar");
        btn_insertar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_insertarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_insertar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 130, 50));

        btn_cancelar.setBackground(new java.awt.Color(51, 153, 0));
        btn_cancelar.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancelar.setText("cancelar");
        btn_cancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 130, 50));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 360, 130, 30));

        l_rut.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_rut.setForeground(new java.awt.Color(0, 102, 102));
        l_rut.setText("Rut");
        getContentPane().add(l_rut, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));

        t_rut.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_rut.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_rut, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 170, -1));

        l_fondo.setForeground(new java.awt.Color(0, 102, 102));
        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_insertClientes.jpg"))); // NOI18N
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_insertarActionPerformed
        String nombre = t_nombre.getText().trim();
        String direccion = t_direccion.getText().trim();
        String telefono = t_telefono.getText().trim();
        String rut = t_rut.getText().trim(); // Ahora rut es un String, no int

        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar(); // método conexión SQL

        String sql = "INSERT INTO clientes (rut, nombre, direccion, telefono) VALUES (?, ?, ?, ?)";

        if (rut.isEmpty() || nombre.isEmpty() || direccion.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBES LLENAR TODOS LOS CAMPOS", "ALERTA", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            PreparedStatement insertar = con.prepareStatement(sql);
            insertar.setString(1, rut);
            insertar.setString(2, nombre);
            insertar.setString(3, direccion);
            insertar.setString(4, telefono);

            int resultado = insertar.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "CLIENTE INSERTADO CORRECTAMENTE", "AVISO",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN EL INSERT: " + e.getMessage());
        }

        if (ventanaClientes != null) {
            ventanaClientes.Mostrar("clientes");
        }
    }//GEN-LAST:event_btn_insertarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        dispose();
        new VentanaClientes().setVisible(true);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaInsertarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaInsertarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaInsertarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaInsertarClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaInsertarClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JButton btn_insertar;
    private javax.swing.JLabel l_direccion;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_nombre;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel l_rut;
    private javax.swing.JLabel l_telefono;
    private javax.swing.JLabel l_titulo_ventana;
    private javax.swing.JTextField t_direccion;
    private javax.swing.JTextField t_nombre;
    private javax.swing.JTextField t_rut;
    private javax.swing.JTextField t_telefono;
    // End of variables declaration//GEN-END:variables
}
