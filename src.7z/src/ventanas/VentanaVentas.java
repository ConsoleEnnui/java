package ventanas;

import conexiones.Conexiones;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableCellRenderer;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.io.FileOutputStream;
import java.io.File;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Desktop;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

public class VentanaVentas extends javax.swing.JFrame {

    private int idBoleta;

    public VentanaVentas() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        java.awt.Image icono = Toolkit.getDefaultToolkit().getImage(getClass()
                .getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);
        tablaBoletas();
    }

    // Método para obtener la tabla
    public javax.swing.JTable getTablaBoletas() {
        return tabla_boletas;
    }

    private void tablaBoletas() {
        DefaultTableModel modelo = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "NOMBRE", "RUT", "N° BOLETA", "MONTO", "FECHA", "TIPO"
                }
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabla_boletas.setModel(modelo);
        configurarTabla();
    }

    public void cargarBoletasPorCliente(int idCliente) {
        String sql = """
        WITH UniqueBoletas AS (
            SELECT 
                v.id_venta AS num_boleta,
                c.nombre AS nombre_cliente,
                c.rut AS rut_cliente,
                v.total_venta AS monto,
                v.fecha_venta AS fecha_boleta,
                'Venta' AS tipo_documento
            FROM clientes c
            INNER JOIN ventas v ON c.id_cliente = v.id_cliente
            WHERE c.id_cliente = ?
            
            UNION
            
            SELECT 
                rv.id_reportev AS num_boleta,
                c.nombre AS nombre_cliente,
                c.rut AS rut_cliente,
                rv.valor_venta AS monto,
                rv.fecha AS fecha_boleta,
                'Reporte' AS tipo_documento
            FROM clientes c
            INNER JOIN reportesventa rv ON c.id_cliente = rv.id_cliente
            WHERE c.id_cliente = ?
            AND NOT EXISTS (
                SELECT 1 
                FROM ventas v 
                WHERE v.id_cliente = rv.id_cliente 
                AND DATE(v.fecha_venta) = DATE(rv.fecha)
            )
        )
        SELECT * FROM UniqueBoletas
        ORDER BY fecha_boleta DESC
    """;

        DefaultTableModel modelo = (DefaultTableModel) tabla_boletas.getModel();
        modelo.setRowCount(0);

        try (Connection conn = Conexiones.conectar(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            ps.setInt(2, idCliente); // Para el segundo WHERE en la consulta UNION

            try (ResultSet rs = ps.executeQuery()) {
                boolean datosEncontrados = false;

                while (rs.next()) {
                    datosEncontrados = true;
                    modelo.addRow(new Object[]{
                        rs.getString("num_boleta"),
                        rs.getString("nombre_cliente"),
                        rs.getString("rut_cliente"),
                        rs.getDouble("monto"),
                        rs.getDate("fecha_boleta"),
                        rs.getString("tipo_documento")
                    });
                }

                if (!datosEncontrados) {
                    JOptionPane.showMessageDialog(null, "Este cliente no tiene boletas registradas.",
                            "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                    "Error al cargar las boletas: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //==================== METODO BUSCAR CLIENTES ==============================
    public void BuscaCliente() {
        String NombreCliente = t_nomCliente.getText();
        if (NombreCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NOMBRE DE CLIENTE", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "SELECT cli.id_cliente, cli.nombre, cli.rut, "
                + "SUM(dv.cantidad) AS total_productos, "
                + "SUM(v.total_venta) AS total_gastado, "
                + "MAX(v.fecha_venta) AS ultima_compra "
                + "FROM ventas v "
                + "JOIN clientes cli ON v.id_cliente = cli.id_cliente "
                + "JOIN detalle_venta dv ON v.id_venta = dv.id_venta "
                + "WHERE cli.nombre LIKE ? "
                + "GROUP BY cli.id_cliente, cli.nombre, cli.rut";

        DefaultTableModel modelo = (DefaultTableModel) tabla_boletas.getModel();
        modelo.setRowCount(0); // Limpiar tabla

        try {
            Conexiones conexion = new Conexiones();
            Connection conn = conexion.conectar();
            PreparedStatement consulta = conn.prepareStatement(sql);

            consulta.setString(1, "%" + NombreCliente + "%");

            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                String[] datos = new String[6];
                datos[0] = resultado.getString("id_cliente");
                datos[1] = resultado.getString("nombre");
                datos[2] = resultado.getString("rut");
                datos[3] = resultado.getString("total_productos");
                datos[4] = resultado.getString("total_gastado");
                datos[5] = resultado.getString("ultima_compra");

                modelo.addRow(datos);
            }
            limpiar();

            if (modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "CLIENTE NO EXISTE", "RESULTADO DE BÚSQUEDA",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BÚSQUEDA\n" + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarPorBoleta() {
        String strBoleta = t_NumBoleta.getText().trim();

        if (strBoleta.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR UN NÚMERO DE BOLETA", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int numeroBoleta;
        try {
            numeroBoleta = Integer.parseInt(strBoleta);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "El número de boleta debe ser un entero", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "SELECT cli.id_cliente, cli.nombre, cli.rut, "
                + "SUM(dv.cantidad) AS total_productos, "
                + "v.total_venta AS total_gastado, "
                + "v.fecha_venta AS ultima_compra "
                + "FROM ventas v "
                + "JOIN clientes cli ON v.id_cliente = cli.id_cliente "
                + "JOIN detalle_venta dv ON v.id_venta = dv.id_venta "
                + "WHERE v.id_venta = ? "
                + "GROUP BY cli.id_cliente, cli.nombre, cli.rut, v.total_venta, v.fecha_venta";

        DefaultTableModel modelo = (DefaultTableModel) tabla_boletas.getModel();
        modelo.setRowCount(0); // Limpiar tabla

        try {
            Conexiones conexion = new Conexiones();
            Connection conn = conexion.conectar();
            PreparedStatement consulta = conn.prepareStatement(sql);

            consulta.setInt(1, numeroBoleta);

            ResultSet resultado = consulta.executeQuery();

            while (resultado.next()) {
                String[] datos = new String[6];
                datos[0] = resultado.getString("id_cliente");
                datos[1] = resultado.getString("nombre");
                datos[2] = resultado.getString("rut");
                datos[3] = resultado.getString("total_productos");
                datos[4] = resultado.getString("total_gastado");
                datos[5] = resultado.getString("ultima_compra"); // igual que en BuscaCliente

                modelo.addRow(datos);
            }
            limpiar();
            if (modelo.getRowCount() == 0) {
                JOptionPane.showMessageDialog(null, "No se encontró la boleta.", "Sin resultados",
                        JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR EN LA BÚSQUEDA\n" + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //======================= ESTRUCTURA DE MAPEO ==============================
    private Map<String, Object> obtenerDetalleVenta(String idDocumento, String fecha) {
        Map<String, Object> resultadoFinal = new HashMap<>();
        List<Map<String, String>> detalles = new ArrayList<>();
        double totalBoleta = 0.0;

        if (idDocumento == null || idDocumento.trim().isEmpty() || fecha == null || fecha.trim().isEmpty()) {
            resultadoFinal.put("detalles", detalles);
            resultadoFinal.put("total", totalBoleta);
            return resultadoFinal;
        }

        try (Connection conn = Conexiones.conectar()) {
            // Intentar primero como venta normal
            String sqlVenta = """
        SELECT 
            p.nombre AS nombre_producto,  -- Se corrigió aquí: ahora usa "p.nombre"
            dv.cantidad,
            dv.precio_unitario AS precio_unitario,
            (dv.cantidad * dv.precio_unitario) AS subtotal
        FROM ventas v
        JOIN detalle_venta dv ON v.id_venta = dv.id_venta
        JOIN productos p ON dv.id_producto = p.id_producto
        WHERE v.id_venta = ? AND DATE(v.fecha_venta) = DATE(?)
        """;

            try (PreparedStatement ps = conn.prepareStatement(sqlVenta)) {
                ps.setString(1, idDocumento);
                ps.setString(2, fecha);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Map<String, String> detalle = new HashMap<>();
                        detalle.put("producto", rs.getString("nombre_producto"));
                        detalle.put("cantidad", rs.getString("cantidad"));
                        detalle.put("precio", rs.getString("precio_unitario"));
                        detalle.put("subtotal", rs.getString("subtotal"));

                        totalBoleta += rs.getDouble("subtotal");
                        detalles.add(detalle);
                    }
                }
            }

            if (detalles.isEmpty()) {
                String sqlReporte = """
            SELECT 
                nombre_cliente AS nombre_producto,
                1 as cantidad,
                valor_venta as precio_unitario,
                valor_venta as subtotal
            FROM reportesventa
            WHERE id_reportev = ? AND DATE(fecha) = DATE(?)
            """;

                try (PreparedStatement ps = conn.prepareStatement(sqlReporte)) {
                    ps.setString(1, idDocumento);
                    ps.setString(2, fecha);

                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            Map<String, String> detalle = new HashMap<>();
                            detalle.put("producto", rs.getString("nombre_producto"));
                            detalle.put("cantidad", rs.getString("cantidad"));
                            detalle.put("precio", rs.getString("precio_unitario"));
                            detalle.put("subtotal", rs.getString("subtotal"));

                            totalBoleta += rs.getDouble("subtotal");
                            detalles.add(detalle);
                        }
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("Error obteniendo detalles: " + e.getMessage());
            e.printStackTrace();
        }

        resultadoFinal.put("detalles", detalles);
        resultadoFinal.put("total", totalBoleta);
        return resultadoFinal;
    }

    //==================== METODOS ACCION LISTENER =============================
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b_imprimir = new javax.swing.JButton();
        t_NumBoleta = new javax.swing.JTextField();
        t_nomCliente = new javax.swing.JTextField();
        l_NumBoleta = new javax.swing.JLabel();
        l_nomCliente = new javax.swing.JLabel();
        b_buscar = new javax.swing.JButton();
        t_clientes = new javax.swing.JScrollPane();
        tabla_boletas = new javax.swing.JTable();
        b_volver = new javax.swing.JButton();
        b_salir = new javax.swing.JButton();
        l_modulo = new javax.swing.JLabel();
        l_pieVentana = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        b_refresh1 = new javax.swing.JButton();
        logo_principal = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MODULO DE VENTAS");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        b_imprimir.setBackground(new java.awt.Color(51, 153, 0));
        b_imprimir.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        b_imprimir.setForeground(new java.awt.Color(255, 255, 255));
        b_imprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/factura.png"))); // NOI18N
        b_imprimir.setText("Imprimir");
        b_imprimir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_imprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_imprimirActionPerformed(evt);
            }
        });
        getContentPane().add(b_imprimir, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 160, 170, 40));

        t_NumBoleta.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_NumBoleta, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 120, 60, 30));

        t_nomCliente.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(t_nomCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 160, 130, 30));

        l_NumBoleta.setBackground(new java.awt.Color(51, 153, 0));
        l_NumBoleta.setForeground(new java.awt.Color(0, 0, 0));
        l_NumBoleta.setText("Num boleta");
        getContentPane().add(l_NumBoleta, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 130, 90, -1));

        l_nomCliente.setBackground(new java.awt.Color(51, 153, 0));
        l_nomCliente.setForeground(new java.awt.Color(0, 0, 0));
        l_nomCliente.setText("Nombre clliente");
        getContentPane().add(l_nomCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 170, 90, -1));

        b_buscar.setBackground(new java.awt.Color(51, 153, 0));
        b_buscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        b_buscar.setForeground(new java.awt.Color(255, 255, 255));
        b_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        b_buscar.setText("Buscar");
        b_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(b_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 130, 110, 70));

        tabla_boletas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "BOLETA", "CLIENTE", "CANTIDAD PRODUCTOS", "TOTAL", "FECHA_BOLETA"
            }
        ));
        t_clientes.setViewportView(tabla_boletas);

        getContentPane().add(t_clientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 820, 270));

        b_volver.setBackground(new java.awt.Color(51, 153, 0));
        b_volver.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_volver.setForeground(new java.awt.Color(255, 255, 255));
        b_volver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/volver.png"))); // NOI18N
        b_volver.setText("volver");
        b_volver.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_volverActionPerformed(evt);
            }
        });
        getContentPane().add(b_volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 520, 110, 40));

        b_salir.setBackground(new java.awt.Color(51, 153, 0));
        b_salir.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        b_salir.setForeground(new java.awt.Color(255, 255, 255));
        b_salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/salir.png"))); // NOI18N
        b_salir.setText("salir");
        b_salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_salirActionPerformed(evt);
            }
        });
        getContentPane().add(b_salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 520, 110, 40));

        l_modulo.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_modulo.setForeground(new java.awt.Color(0, 102, 102));
        l_modulo.setText("Boletas");
        getContentPane().add(l_modulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 30, -1, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 530, 130, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Buscar Boleta:  ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, -1, -1));

        b_refresh1.setBackground(new java.awt.Color(204, 204, 204));
        b_refresh1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        b_refresh1.setForeground(new java.awt.Color(255, 255, 255));
        b_refresh1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cargando (5).png"))); // NOI18N
        b_refresh1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        b_refresh1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_refresh1ActionPerformed(evt);
            }
        });
        getContentPane().add(b_refresh1, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 240, 40, 40));

        logo_principal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_principal.jpg"))); // NOI18N
        getContentPane().add(logo_principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_ventas.jpg"))); // NOI18N
        l_fondo.setToolTipText("");
        l_fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b_imprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_imprimirActionPerformed
        int fila = tabla_boletas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione una boleta para imprimir.",
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String idDocumento = tabla_boletas.getValueAt(fila, 0).toString();
            String nombreCliente = tabla_boletas.getValueAt(fila, 1).toString();
            String rutCliente = tabla_boletas.getValueAt(fila, 2).toString();
            String fechaBoleta = tabla_boletas.getValueAt(fila, 4).toString();
            String tipoDocumento = tabla_boletas.getValueAt(fila, 5).toString();

            Map<String, Object> detallesVenta = obtenerDetalleVenta(idDocumento, fechaBoleta);

            @SuppressWarnings("unchecked")
            List<Map<String, String>> listaDetalles = (List<Map<String, String>>) detallesVenta.get("detalles");
            double totalGastado = (double) detallesVenta.get("total");

            if (listaDetalles.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se encontraron detalles para esta venta.",
                        "Sin detalles", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            Document documento = new Document(PageSize.LETTER);
            String rutaArchivo = "D:/UST 2/Integracion de Competencias I/Orion/AlmacenPro +/ventas clientes administracion" + idDocumento + ".pdf";
            PdfWriter.getInstance(documento, new FileOutputStream(rutaArchivo));
            documento.open();

            Font fuenteNormal = new Font(Font.FontFamily.HELVETICA, 10);
            Font fuenteNegrita = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

            documento.add(new Paragraph("Almacen Pro+ S.A.", fuenteNegrita));
            documento.add(new Paragraph("Dirección: Calle Falsa, 123", fuenteNormal));
            documento.add(new Paragraph("Teléfono: 123 456 7890", fuenteNormal));
            documento.add(new Paragraph("\n"));
            documento.add(new Paragraph("BOLETA DE VENTA", new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD)));
            documento.add(new Paragraph("\n"));

            documento.add(new Paragraph("Cliente: " + nombreCliente, fuenteNormal));
            documento.add(new Paragraph("RUT: " + rutCliente, fuenteNormal));
            documento.add(new Paragraph("ID Cliente: " + idDocumento, fuenteNormal));
            documento.add(new Paragraph("Fecha: " + fechaBoleta, fuenteNormal));
            documento.add(new Paragraph("Tipo: " + tipoDocumento, fuenteNormal));
            documento.add(new Paragraph("\n"));

            PdfPTable tablaPDF = new PdfPTable(4);
            tablaPDF.setWidthPercentage(100);
            tablaPDF.setWidths(new float[]{2.5f, 1f, 1f, 1f});

            tablaPDF.addCell(new PdfPCell(new Phrase("Producto", fuenteNegrita)));
            tablaPDF.addCell(new PdfPCell(new Phrase("Cantidad", fuenteNegrita)));
            tablaPDF.addCell(new PdfPCell(new Phrase("Precio Unit.", fuenteNegrita)));
            tablaPDF.addCell(new PdfPCell(new Phrase("Subtotal", fuenteNegrita)));

            for (Map<String, String> detalle : listaDetalles) {
                tablaPDF.addCell(new Phrase(detalle.get("producto"), fuenteNormal));
                tablaPDF.addCell(new Phrase(detalle.get("cantidad"), fuenteNormal));
                tablaPDF.addCell(new Phrase("$" + detalle.get("precio"), fuenteNormal));
                tablaPDF.addCell(new Phrase("$" + detalle.get("subtotal"), fuenteNormal));
            }

            documento.add(tablaPDF);
            documento.add(new Paragraph("\n"));
            Paragraph total = new Paragraph("Total: $" + totalGastado, fuenteNegrita);
            total.setAlignment(Element.ALIGN_RIGHT);
            documento.add(total);

            documento.close();
            JOptionPane.showMessageDialog(null, "Boleta generada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            Desktop.getDesktop().open(new File(rutaArchivo));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al generar la boleta: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_b_imprimirActionPerformed

    private void b_volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_volverActionPerformed
        dispose();
        new VentanaVentasBoleta().setVisible(true);
    }//GEN-LAST:event_b_volverActionPerformed

    private void b_salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_salirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(null,
                "CONFIRMA SALIR DE LA APLICACION?",
                "CONFIRMAR SALIDA",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_b_salirActionPerformed

    private void b_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_buscarActionPerformed
        if (!t_nomCliente.getText()
                .isEmpty()) {
            BuscaCliente();
        } else if (!t_NumBoleta.getText()
                .isEmpty()) {
            buscarPorBoleta();
        } else {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR NOMBRE DE CLIENTE\n"
                    + "O DE FACTURA A BUSCAR", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    //====================== METODOS AUXILIARES ================================
    private void configurarTabla() {
        tabla_boletas.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabla_boletas.setEnabled(true); // permitir selección visual

        tabla_boletas.setRowSelectionAllowed(true);
        tabla_boletas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        tabla_boletas.setSelectionBackground(new Color(0, 120, 215)); // azul
        tabla_boletas.setSelectionForeground(Color.WHITE); // texto blanco
    }

    public void centrarTexto(JTable tabla) {
        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centrado);
        }

    }//GEN-LAST:event_b_buscarActionPerformed

    private void limpiar() {
        t_nomCliente.setText("");
        t_NumBoleta.setText("");
    }

    private void b_refresh1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_refresh1ActionPerformed
//        mostrar(idBoleta);
        cargarBoletasPorCliente(idBoleta);
    }//GEN-LAST:event_b_refresh1ActionPerformed

// Método auxiliar para limpiar la tabla
    private void limpiarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tabla_boletas.getModel();
        modelo.setRowCount(0);
    }

    //====================== CONECCION =========================================
    Conexiones conexion = new Conexiones();
    java.sql.Connection con = conexion.conectar();

    //=================== METODO MAIN  =========================================
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_buscar;
    private javax.swing.JButton b_imprimir;
    private javax.swing.JButton b_refresh1;
    private javax.swing.JButton b_salir;
    private javax.swing.JButton b_volver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel l_NumBoleta;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_modulo;
    private javax.swing.JLabel l_nomCliente;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel logo_principal;
    private javax.swing.JTextField t_NumBoleta;
    private javax.swing.JScrollPane t_clientes;
    private javax.swing.JTextField t_nomCliente;
    private javax.swing.JTable tabla_boletas;
    // End of variables declaration//GEN-END:variables

}
