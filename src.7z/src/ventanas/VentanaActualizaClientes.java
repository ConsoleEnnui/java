package ventanas;

import conexiones.Conexiones;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class VentanaActualizaClientes extends javax.swing.JFrame {

    public VentanaActualizaClientes() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        Image icono = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/imagenes/almacen1.jpg"));
        setIconImage(icono);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_titulo_ventana = new javax.swing.JLabel();
        l_nombre = new javax.swing.JLabel();
        l_direccion = new javax.swing.JLabel();
        l_telefono = new javax.swing.JLabel();
        t_nombre = new javax.swing.JTextField();
        t_direccion = new javax.swing.JTextField();
        t_telefono = new javax.swing.JTextField();
        btn_actualizar = new javax.swing.JButton();
        btn_cancelar = new javax.swing.JButton();
        l_idcCliente = new javax.swing.JLabel();
        t_idCliente = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        l_pieVentana = new javax.swing.JLabel();
        l_fondo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Insertar clientes");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        l_titulo_ventana.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        l_titulo_ventana.setForeground(new java.awt.Color(0, 102, 102));
        l_titulo_ventana.setText("Actualizar cliente");
        getContentPane().add(l_titulo_ventana, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, -1, -1));

        l_nombre.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_nombre.setForeground(new java.awt.Color(0, 102, 102));
        l_nombre.setText("Telefono");
        getContentPane().add(l_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, -1, -1));

        l_direccion.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_direccion.setForeground(new java.awt.Color(0, 102, 102));
        l_direccion.setText("Direccion");
        getContentPane().add(l_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, -1, -1));

        l_telefono.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_telefono.setForeground(new java.awt.Color(0, 102, 102));
        l_telefono.setText("Nombre");
        getContentPane().add(l_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, -1, -1));

        t_nombre.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_nombre.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 170, -1));

        t_direccion.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_direccion.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 370, -1));

        t_telefono.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_telefono.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 170, -1));

        btn_actualizar.setBackground(new java.awt.Color(51, 153, 0));
        btn_actualizar.setForeground(new java.awt.Color(255, 255, 255));
        btn_actualizar.setText("Actualizar");
        btn_actualizar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_actualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 130, 50));

        btn_cancelar.setBackground(new java.awt.Color(51, 153, 0));
        btn_cancelar.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancelar.setText("Cancelar");
        btn_cancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 130, 50));

        l_idcCliente.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        l_idcCliente.setForeground(new java.awt.Color(0, 102, 102));
        l_idcCliente.setText("id Cliente");
        getContentPane().add(l_idcCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, -1, -1));

        t_idCliente.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        t_idCliente.setForeground(new java.awt.Color(0, 102, 102));
        getContentPane().add(t_idCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 60, -1));

        btn_buscar.setBackground(new java.awt.Color(51, 153, 0));
        btn_buscar.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btn_buscar.setForeground(new java.awt.Color(255, 255, 255));
        btn_buscar.setText("Buscar");
        btn_buscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });
        getContentPane().add(btn_buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 70, -1));

        l_pieVentana.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        l_pieVentana.setForeground(new java.awt.Color(0, 0, 0));
        l_pieVentana.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/orion-system.png"))); // NOI18N
        l_pieVentana.setText("Orion system");
        getContentPane().add(l_pieVentana, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 200, 50));

        l_fondo.setForeground(new java.awt.Color(0, 102, 102));
        l_fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo_insertClientes.jpg"))); // NOI18N
        getContentPane().add(l_fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //=================== METODOS ACTION LISTENER ==============================
    private void btn_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_actualizarActionPerformed
        String idCliente = t_idCliente.getText().trim();
        String nombre = t_nombre.getText().trim();
        String direccion = t_direccion.getText().trim();
        String telefono = t_telefono.getText().trim();

        if (idCliente.isEmpty() || nombre.isEmpty() || direccion.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(null, "TODOS LOS CAMPOS DEBEN ESTAR LLENOS", "ALERTA",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar();

        if (con == null) {
            JOptionPane.showMessageDialog(null, "NO SE PUDO CONECTAR A LA BASE DE DATOS", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String verificaCliente = "SELECT COUNT(*) FROM clientes WHERE id_cliente = ?";
        String actualizar = "UPDATE clientes SET nombre = ?, direccion = ?, telefono = ? WHERE id_cliente = ?";

        try {
            PreparedStatement verificar = con.prepareStatement(verificaCliente);
            verificar.setInt(1, Integer.parseInt(idCliente));
            ResultSet resultado = verificar.executeQuery();

            if (resultado.next()) {
                int existe = resultado.getInt(1);

                if (existe > 0) {
                    try {
                        PreparedStatement p_actualizar = con.prepareStatement(actualizar);
                        p_actualizar.setString(1, nombre);
                        p_actualizar.setString(2, direccion);
                        p_actualizar.setString(3, telefono);
                        p_actualizar.setInt(4, Integer.parseInt(idCliente));

                        int actualizacion = p_actualizar.executeUpdate();
                        if (actualizacion > 0) {
                            JOptionPane.showMessageDialog(null, "CLIENTE ACTUALIZADO CORRECTAMENTE");
                            t_nombre.setText("");
                            t_direccion.setText("");
                            t_telefono.setText("");
                            t_idCliente.setText("");
                        } else {
                            JOptionPane.showMessageDialog(null, "NO SE PUDO ACTUALIZAR EL CLIENTE", "ERROR",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "ERROR SQL AL ACTUALIZAR: " + e.getMessage(), "ERROR",
                                JOptionPane.ERROR_MESSAGE);
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "EL CLIENTE CON ESE ID NO EXISTE", "ERROR",
                            JOptionPane.ERROR_MESSAGE);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR SQL EN LA CONSULTA: " + e.getMessage(), "ERROR",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_btn_actualizarActionPerformed

    private void btn_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelarActionPerformed
        dispose();
        new VentanaClientes().setVisible(true);
    }//GEN-LAST:event_btn_cancelarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        String idCliente = t_idCliente.getText().trim();

        if (idCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "DEBE INGRESAR UN ID DE CLIENTE", "ALERTA",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String sql = "select Nombre, Direccion , Telefono from clientes where id_cliente = ? ";

        Conexiones conexion = new Conexiones();
        Connection con = conexion.conectar();

        try {
            PreparedStatement consulta = con.prepareStatement(sql);
            consulta.setInt(1, Integer.parseInt(idCliente));
            ResultSet resultado = consulta.executeQuery();

            if (resultado.next()) {
                t_nombre.setText(resultado.getString("nombre"));
                t_direccion.setText(resultado.getString("direccion"));
                t_telefono.setText(resultado.getString("telefono"));

            } else {
                JOptionPane.showMessageDialog(null, "CLIENTE NO ENCONTRADO");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_buscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaActualizaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaActualizaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaActualizaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaActualizaClientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaActualizaClientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_actualizar;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btn_cancelar;
    private javax.swing.JLabel l_direccion;
    private javax.swing.JLabel l_fondo;
    private javax.swing.JLabel l_idcCliente;
    private javax.swing.JLabel l_nombre;
    private javax.swing.JLabel l_pieVentana;
    private javax.swing.JLabel l_telefono;
    private javax.swing.JLabel l_titulo_ventana;
    private javax.swing.JTextField t_direccion;
    private javax.swing.JTextField t_idCliente;
    private javax.swing.JTextField t_nombre;
    private javax.swing.JTextField t_telefono;
    // End of variables declaration//GEN-END:variables
}
