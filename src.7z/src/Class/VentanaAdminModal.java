package Class;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class VentanaAdminModal extends JDialog {
    private boolean accesoConcedido = false;

    public boolean isAccesoConcedido() {
        return accesoConcedido;
    }

    public VentanaAdminModal() {
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 150));
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        setModal(true);

        JPanel panelRedondeado = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 40, 40));
                g2.dispose();
            }
        };
        panelRedondeado.setOpaque(false);
        panelRedondeado.setPreferredSize(new Dimension(600, 300));
        panelRedondeado.setLayout(new BorderLayout(20, 20));

        JLabel label = new JLabel("¿Desea permitir que esta aplicación realice cambios en su dispositivo?", SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        panelRedondeado.add(label, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 10));
        botones.setOpaque(false);

        JButton btnSi = new JButton("Sí");
        JButton btnNo = new JButton("No");

        btnSi.setPreferredSize(new Dimension(100, 35));
        btnNo.setPreferredSize(new Dimension(100, 35));

        btnSi.addActionListener(e -> {
            accesoConcedido = true; // <<< Se concedió acceso
            dispose();
        });

        btnNo.addActionListener(e -> {
            accesoConcedido = false; // <<< No se concedió acceso
            dispose();
        });

        botones.add(btnSi);
        botones.add(btnNo);
        panelRedondeado.add(botones, BorderLayout.SOUTH);
        add(panelRedondeado, new GridBagConstraints());
    }
}
